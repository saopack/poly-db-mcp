"""Implementation of the unsigned integer adaptation objects

This module exists to avoid a circular import problem: psycopg2.extras depends
on psycopg2.extensions, so I can't create the default unsigned typecasters in
extensions importing register_unsigned_types from extras.
"""

# psycopg/_unsinged_int.py - Implementation of the unsigned integer adaptation objects
#
# Copyright (C) 2012-2019 Daniele Varrazzo  <daniele.varrazzo@gmail.com>
# Copyright (C) 2020-2021 The Psycopg Team
#
# psycopg2 is free software: you can redistribute it and/or modify it
# under the terms of the GNU Lesser General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# In addition, as a special exception, the copyright holders give
# permission to link this program with the OpenSSL library (or with
# modified versions of OpenSSL that use the same license as OpenSSL),
# and distribute linked combinations including the two.
#
# You must obey the GNU Lesser General Public License in all respects for
# all of the code used other than OpenSSL.
#
# psycopg2 is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
# License for more details.

import psycopg2
from psycopg2.extensions import cursor, new_type, new_array_type, register_type


def _cast_uint(value, cur):
    """通用的无符号整型转换器，直接转换为 Python int"""
    if value is None:
        return None
    return int(value)


def register_uint1_info(oid, array_oid, scope):
    """注册 uint1 类型信息"""
    uint1_type = new_type((oid,), "UINT1", _cast_uint)
    register_type(uint1_type, scope)
    
    if array_oid is not None:
        uint1_array = new_array_type((array_oid,), "UINT1[]", uint1_type)
        register_type(uint1_array, scope)


def register_uint2_info(oid, array_oid, scope):
    """注册 uint2 类型信息"""
    uint2_type = new_type((oid,), "UINT2", _cast_uint)
    register_type(uint2_type, scope)
    
    if array_oid is not None:
        uint2_array = new_array_type((array_oid,), "UINT2[]", uint2_type)
        register_type(uint2_array, scope)


def register_uint4_info(oid, array_oid, scope):
    """注册 uint4 类型信息"""
    uint4_type = new_type((oid,), "UINT4", _cast_uint)
    register_type(uint4_type, scope)
    
    if array_oid is not None:
        uint4_array = new_array_type((array_oid,), "UINT4[]", uint4_type)
        register_type(uint4_array, scope)


def register_uint8_info(oid, array_oid, scope):
    """注册 uint8 类型信息"""
    uint8_type = new_type((oid,), "UINT8", _cast_uint)
    register_type(uint8_type, scope)
    
    if array_oid is not None:
        uint8_array = new_array_type((array_oid,), "UINT8[]", uint8_type)
        register_type(uint8_array, scope)


def register_unsigned_types(conn_or_curs=None, globally=True, arrays=False):
    """
    注册无符号整型支持
    
    参数:
        conn_or_curs: 数据库连接或游标对象
        globally: 是否全局注册(默认 True)
        arrays: 是否注册数组类型(默认 False)
        
    使用示例:
        >>> import psycopg2.extras
        >>> conn = psycopg2.connect(...)
        >>> psycopg2.extras.register_unsigned_types(conn)
    """
    # 获取连接对象
    conn = conn_or_curs if hasattr(conn_or_curs, 'cursor') else conn_or_curs.connection
    cur = conn.cursor(cursor_factory=cursor)
    scope = None if globally else conn_or_curs
    
    # 使用 to_regtype 获取搜索路径中的第一个匹配类型
    cur.execute("""
        SELECT typname, oid 
        FROM pg_type 
        WHERE typname IN (
            'uint1', '_uint1',
            'uint2', '_uint2',
            'uint4', '_uint4',
            'uint8', '_uint8'
        )
    """)
    type_info = dict(cur.fetchall())
    
    # 只在有类型存在时注册，不强制要求所有类型都存在
    registered = []
    
    if 'uint1' in type_info:
        register_uint1_info(
            type_info['uint1'], 
            type_info.get('_uint1') if arrays else None, 
            scope
        )
        registered.append('uint1')
    
    if 'uint2' in type_info:
        register_uint2_info(
            type_info['uint2'], 
            type_info.get('_uint2') if arrays else None, 
            scope
        )
        registered.append('uint2')
    
    if 'uint4' in type_info:
        register_uint4_info(
            type_info['uint4'], 
            type_info.get('_uint4') if arrays else None, 
            scope
        )
        registered.append('uint4')
    
    if 'uint8' in type_info:
        register_uint8_info(
            type_info['uint8'], 
            type_info.get('_uint8') if arrays else None, 
            scope
        )
        registered.append('uint8')
    
    cur.close()
    
    # 如果没有找到任何无符号类型，抛出异常
    if not registered:
        raise psycopg2.ProgrammingError(
            'no unsigned types found in the database. '
            'You may need to install an extension that provides unsigned types.'
        )
    
    return registered
