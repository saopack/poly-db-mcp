#!/usr/bin/env python

import unittest
import sys 
sys.path.append("..") 
import testutils
from testutils import ConnectingTestCase

import psycopg2
import binascii

class LongRawTest(ConnectingTestCase):
    """Test that all type conversions are working."""

    def execute(self, *args):
        curs = self.conn.cursor()
        curs.execute(*args)
        return curs.fetchone()[0]

    def test_longraw(self):
        self.conn.autocommit = True
        curs = self.conn.cursor()
        curs.execute("drop table if exists test_longraw;")
        curs.execute("create table test_longraw(c1 int, c2 long raw);")
        value='this is a test of testLongRaw'
        hex = (b'hello')
        try:
            curs.execute("insert into test_longraw values (%s, %s::raw);",(1, hex, ))
            curs.execute("insert into test_longraw values (2, utl_raw.cast_to_raw(%s));", (value, ))
            curs.execute("insert into test_longraw values (3, '123456ABD');")
            curs.execute("delete from test_longraw where c2=%s::raw;", (hex, ))
            curs.execute("update test_longraw set c2=%s::raw where c2='123456ABD';",( hex, ))
            curs.execute("select * from test_longraw;")

            re = curs.fetchall()

            self.assertEqual(bytes,type(re[0][1][0]))
            self.assertEqual(value,eval(str(binascii.unhexlify(re[0][1])).split('b')[1]))
            self.assertEqual(hex, binascii.unhexlify(re[1][1]))

        finally:
            curs.execute("drop table test_longraw;")
            self.conn.commit()
            curs.closed
            self.conn.closed

def test_suite():
    return unittest.TestLoader().loadTestsFromName(__name__)


if __name__ == "__main__":
    unittest.main()
