#!/usr/bin/env python

import unittest
import sys 
sys.path.append("..") 
import testutils
from testutils import ConnectingTestCase

import psycopg2


class LongTest(ConnectingTestCase):
    """Test that all type conversions are working."""

    def execute(self, *args):
        curs = self.conn.cursor()
        curs.execute(*args)
        return curs.fetchone()[0]

    def test_long(self):
        self.conn.autocommit = True
        curs = self.conn.cursor()
        curs.execute("drop table if exists test_long;")
        curs.execute('create table test_long(col1 int,col2 long);')
        try:
            curs.execute("insert into test_long values (%s,%s)", (1,"this is a LongTest",))
            curs.execute("insert into test_long values (%s,%s)", (2,"this is a LongTest2",))
            curs.execute("delete from test_long where col1=2;")
            curs.execute("select * from test_long;")
            x = curs.fetchall()
            
            self.assert_(isinstance(x[0][1], str))
            self.assertEqual(1, x[0][0])
            self.assertEqual('this is a LongTest', x[0][1])

            curs.execute("update test_long set col2=%s where col1=%s", ('this is a LongTest2', 1))
            curs.execute("select col2 from test_long where col1=1")
            
            self.assertEqual('this is a LongTest2', curs.fetchone()[0])
        finally:
            curs.execute("drop table test_long;")
            self.conn.commit()
            curs.closed
            self.conn.closed

def test_suite():
    return unittest.TestLoader().loadTestsFromName(__name__)


if __name__ == "__main__":
    unittest.main()
