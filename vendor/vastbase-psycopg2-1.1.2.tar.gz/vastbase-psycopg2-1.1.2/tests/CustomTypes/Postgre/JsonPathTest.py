#!/usr/bin/env python

import unittest
import sys 
sys.path.append("..") 
import testutils
from testutils import ConnectingTestCase

import psycopg2

class LongRawTest(ConnectingTestCase):
    """Test that all type conversions are working."""

    def execute(self, *args):
        curs = self.conn.cursor()
        curs.execute(*args)
        return curs.fetchone()[0]

    def test_longraw(self):
        self.conn.autocommit = True
        curs = self.conn.cursor()
        curs.execute("drop table if exists test_jsonpath;")
        curs.execute("create table test_jsonpath(c1 int, c2 jsonpath);")
        value1='"this is a JsonPathTest1"'
        value2='"this is a JsonPathTest2"'
        value3='"this is a JsonPathTest3"'
        value4='"this is a JsonPathTest4"'
        try:
            curs.execute("insert into test_jsonpath values (%s, %s);",(1, value1, ))
            curs.execute("insert into test_jsonpath values (%s, %s);",(2, value2, ))
            curs.execute("insert into test_jsonpath values (%s, %s);",(3, value3, ))
            curs.execute("delete from test_jsonpath where c1 = %s;", (2, ))
            curs.execute("update test_jsonpath set c2=%s where c1=3;", (value4, ))
            curs.execute("select * from test_jsonpath;")

            re = curs.fetchall()
            
            self.assertEqual(str,type(re[0][1]))
            self.assertEqual(value1,re[0][1])
            self.assertEqual(value4, re[1][1])
            
        finally:
            curs.execute("drop table test_jsonpath;")
            self.conn.commit()
            curs.closed
            self.conn.closed

def test_suite():
    return unittest.TestLoader().loadTestsFromName(__name__)


if __name__ == "__main__":
    unittest.main()
