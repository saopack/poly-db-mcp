#!/usr/bin/env python
#
# test_sparsevector.py - tests for sparsevector types conversions
#
# Copyright (C) 2004-2019 Federico Di Gregorio  <fog@debian.org>
# Copyright (C) 2020-2021 The Psycopg Team
#
# psycopg2 is free software: you can redistribute it and/or modify it
# under the terms of the GNU Lesser General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# In addition, as a special exception, the copyright holders give
# permission to link this program with the OpenSSL library (or with
# modified versions of OpenSSL that use the same license as OpenSSL),
# and distribute linked combinations including the two.
#
# You must obey the GNU Lesser General Public License in all respects for
# all of the code used other than OpenSSL.
#
# psycopg2 is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
# License for more details.

import io
import random
import unittest
# import testutils
import struct
from typing import Any, Dict, List, Tuple
from .testutils import ConnectingTestCase

import psycopg2
from psycopg2.extensions import SparseVector


class TestSparseVector(ConnectingTestCase):
    """测试 psycopg2.extensions.SparseVector 类型"""

    def setUp(self):
        """设置测试环境"""
        super(TestSparseVector, self).setUp()

        # 创建测试表
        cur = self.conn.cursor()
        try:
            cur.execute("DROP TABLE IF EXISTS sparsevector_test;")
            cur.execute("CREATE TABLE sparsevector_test (id serial PRIMARY KEY, vec sparsevector);")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            cur.close()

    def tearDown(self):
        """清理测试环境"""
        # 确保任何未完成的事务被回滚
        self.conn.rollback()

        cur = self.conn.cursor()
        try:
            cur.execute("DROP TABLE IF EXISTS sparsevector_test;")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
        finally:
            cur.close()

        super(TestSparseVector, self).tearDown()

    def test_constructor_with_dict(self):
        """测试使用字典构造 SparseVector"""
        vec_dict = {0: 1.0, 2: 2.5, 5: 3.7}
        max_dim = 10
        vec = SparseVector((vec_dict, max_dim))

    def test_constructor_with_pair_list(self):
        """测试使用键值对列表构造 SparseVector"""
        pair_list = [(0, 1.0), (2, 2.5), (5, 3.7)]
        max_dim = 10
        vec = SparseVector((pair_list, max_dim))


    def test_constructor_with_tuple_pairs(self):
        """测试使用元组对列表构造 SparseVector"""
        pairs = ((1, 2.0), (3, 4.5), (7, 6.8))
        max_dim = 12
        vec = SparseVector((pairs, max_dim))

    def test_write_sparsevector_to_database(self):
        """测试将 SparseVector 对象写入数据库"""
        vec_dict = {0: 1.0, 2: 2.5, 5: 3.7, 8: -4.2}
        max_dim = 15
        vec = SparseVector((vec_dict, max_dim))

        curs = self.conn.cursor()
        try:
            curs.execute("INSERT INTO sparsevector_test (vec) VALUES (%s) RETURNING id;", (vec,))
            row_id = curs.fetchone()[0]

            # 验证插入成功
            curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]
            print(f"预期向量，ID: {row_id}, 向量: {result}")

            self.assertIsInstance(result, SparseVector)
            # result_list = result.tolist()
            # self.assertEqual(len(result_list), max_dim)

            # for idx, val in vec_dict.items():
            #     self.assertAlmostEqual(result_list[idx], val, places=5)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_write_dict_to_database(self):
        """直接使用 Python dict 对象写入数据库"""
        vec_dict = {1: 1.0, 3: 2.5, 7: 3.7}
        max_dim = 10

        curs = self.conn.cursor()
        try:
            # 使用 dict 和 max_dim 一起插入
            curs.execute(
                "INSERT INTO sparsevector_test (vec) VALUES (%s) RETURNING id;",
                (SparseVector((vec_dict, max_dim)),)
            )
            row_id = curs.fetchone()[0]

            # 验证插入成功
            curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, SparseVector)
            # result_list = result.tolist()
            # self.assertEqual(len(result_list), max_dim)

            # for idx, val in vec_dict.items():
            #     self.assertAlmostEqual(result_list[idx], val, places=5)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_write_sparse_string_to_database(self):
        """测试使用稀疏向量字符串格式写入数据库"""
        # 使用 PostgreSQL sparsevector 格式
        sparse_str = "'{1:2.5,3:4.0,5:-1.2}'"
        max_dim = 10

        curs = self.conn.cursor()
        try:
            curs.execute(f"INSERT INTO sparsevector_test (vec) VALUES ({sparse_str}::sparsevector) RETURNING id;")
            row_id = curs.fetchone()[0]

            # 验证插入成功
            curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, SparseVector)
            # result_list = result.tolist()
            # self.assertEqual(len(result_list), 10)
            # self.assertAlmostEqual(result_list[1], 2.5, places=5)
            # self.assertAlmostEqual(result_list[3], 4.0, places=5)
            # self.assertAlmostEqual(result_list[5], -1.2, places=5)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    # def test_write_array_sparse_to_database(self):
    #     """测试使用 ARRAY 语法写入稀疏向量"""
    #     # 转换为 spasevec 类型
    #     sparse_str = "ARRAY[0,1,0,2.5,0,3.7,0,0,0,-1.2]::floatvector::sparsevector"

    #     curs = self.conn.cursor()
    #     try:
    #         curs.execute(f"INSERT INTO sparsevector_test (vec) VALUES ({sparse_str}) RETURNING id;")
    #         row_id = curs.fetchone()[0]

    #         # 验证插入成功
    #         curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
    #         result = curs.fetchone()[0]

    #         self.assertIsInstance(result, SparseVector)
    #         result_list = result.tolist()
    #         self.assertEqual(len(result_list), 10)
    #         self.assertAlmostEqual(result_list[1], 1.0, places=5)
    #         self.assertAlmostEqual(result_list[3], 2.5, places=5)
    #         self.conn.commit()
    #     except Exception:
    #         self.conn.rollback()
    #         raise
    #     finally:
    #         curs.close()

    def test_read_from_database(self):
        """测试从数据库读取 SparseVector"""
        vec_dict = {0: 1.0, 3: 2.5, 7: 3.7}
        max_dim = 12

        curs = self.conn.cursor()
        try:
            # 插入稀疏向量
            vec = SparseVector((vec_dict, max_dim))
            curs.execute("INSERT INTO sparsevector_test (vec) VALUES (%s) RETURNING id;", (vec,))
            row_id = curs.fetchone()[0]

            # 读取并验证
            curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, SparseVector)
            # result_list = result.tolist()
            # self.assertEqual(len(result_list), max_dim)

            # for idx, val in vec_dict.items():
            #     self.assertAlmostEqual(result_list[idx], val, places=5)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_different_sparsity_patterns(self):
        """测试不同的稀疏模式"""
        test_cases = [
            # (sparse_dict, max_dim, description)
            ({0: 1.0, 4: 2.0, 9: 3.0}, 20, "均匀分布"),
            ({0: 1.5, 1: 2.5, 2: 3.5, 3: 4.5}, 10, "密集前段"),
            ({15: 1.0, 16: 2.0, 17: 3.0}, 20, "密集后段"),
            ({0: 10.0}, 100, "单个元素"),
            ({i: float(i+1) for i in range(0, 50, 5)}, 100, "多个元素"),
        ]

        curs = self.conn.cursor()
        try:
            for vec_dict, max_dim, desc in test_cases:
                vec = SparseVector((vec_dict, max_dim))

                curs.execute("INSERT INTO sparsevector_test (vec) VALUES (%s) RETURNING id;", (vec,))
                row_id = curs.fetchone()[0]

                curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
                result = curs.fetchone()[0]

                self.assertIsInstance(result, SparseVector)
                # result_list = result.tolist()
                # self.assertEqual(len(result_list), max_dim)

                # for idx, val in vec_dict.items():
                #     self.assertAlmostEqual(result_list[idx], val, places=5)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_zero_and_negative_values(self):
        """测试零值和负值的处理"""
        vec_dict = {1: -1.0, 5: -5.5, 9: -9.9}
        max_dim = 15

        vec = SparseVector((vec_dict, max_dim))

        # 验证可以插入数据库
        curs = self.conn.cursor()
        try:
            curs.execute("INSERT INTO sparsevector_test (vec) VALUES (%s) RETURNING id;", (vec,))
            row_id = curs.fetchone()[0]

            curs.execute("SELECT vec FROM sparsevector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, SparseVector)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_invalid_inputs(self):
        """测试无效输入"""
        invalid_inputs = [
            ((None, 10), "None 作为 pairs"),
            (({1: 2.0}, None), "None 作为 max_dim"),
            (({1: 2.0}, -1), "负的 max_dim"),
            (({1: 2.0}, 0), "零 max_dim"),
            (([], "10"), "字符串 max_dim"),
        ]

        for invalid_input, desc in invalid_inputs:
            try:
                vec = SparseVector(invalid_input)
                print(f"注意: SparseVector 接受 {desc} 作为输入，结果为: {vec}")
            except Exception as e:
                print(f"处理 {desc} 时抛出异常: {type(e).__name__}: {str(e)}")

    def test_invalid_pairs(self):
        """测试无效的键值对"""
        invalid_pairs = [
            ({"a": 2.0}, 10, "字符串索引"),
            ({1: "b"}, 10, "字符串值"),
            ({1: None}, 10, "None 值"),
            ({-1: 2.0}, 10, "负索引"),  # 这个可能应该失败
            ({15: 2.0}, 10, "索引超出 max_dim"),
        ]

        for pairs, max_dim, desc in invalid_pairs:
            try:
                vec = SparseVector((pairs, max_dim))
                print(f"注意: SparseVector 接受 {desc} 作为输入，结果为: {vec}")
            except Exception as e:
                print(f"处理 {desc} 时抛出异常: {type(e).__name__}: {str(e)}")

    def test_adapter_and_typecast(self):
        """测试 SparseVector 的适配器和类型转换功能"""
        vec_dict = {0: 1.0, 2: 2.5, 5: 3.7}
        max_dim = 10
        vec = SparseVector((vec_dict, max_dim))

        # 测试适配器
        adapted = psycopg2.extensions.adapt(vec)
        self.assertIsNotNone(adapted)

        # 检查适配后的结果
        serialized = adapted.getquoted()
        self.assertIsNotNone(serialized)

        # 验证查询结果是否正确转换为 SparseVector 类型
        curs = self.conn.cursor()
        try:
            curs.execute("SELECT %s::sparsevector AS vec", (vec,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, SparseVector)
            # result_list = result.tolist()
            # self.assertEqual(len(result_list), max_dim)

            # for idx, val in vec_dict.items():
            #     self.assertAlmostEqual(result_list[idx], val, places=5)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_str_representation(self):
        """测试 str() 表示形式"""
        vec_dict = {0: 1.0, 2: 2.5}
        max_dim = 10
        vec = SparseVector((vec_dict, max_dim))

        # 测试 str() 返回字符串格式
        str_repr = str(vec)
        self.assertIsInstance(str_repr, str)
        # 应该包含索引和值
        self.assertIn("0", str_repr)
        self.assertIn("2.5", str_repr)

    def test_repr_representation(self):
        """测试 repr() 表示形式"""
        vec_dict = {0: 1.0, 2: 2.5}
        max_dim = 10
        vec = SparseVector((vec_dict, max_dim))

        # 测试 repr() 返回格式
        repr_str = repr(vec)
        self.assertIsInstance(repr_str, str)
        # 应该包含 sparsevector 类型转换
        self.assertIn("sparsevector", repr_str)

    def test_totuple_method(self):
        """测试 totuple() 方法"""
        vec_dict = {0: 1.0, 2: 2.5}
        max_dim = 10
        vec = SparseVector((vec_dict, max_dim))

        result_tuple = vec.totuple()
        self.assertIsInstance(result_tuple, tuple)
        self.assertEqual(len(result_tuple), 2)

    def test_copy_binary(self):
        """使用COPY WITH BINARY将稀疏向量数据复制到PostgreSQL"""
        print("步骤1: 生成稀疏向量数据")
        sparse_vectors = self.generate_random_sparse_vectors(100, 10000)

        # 准备二进制数据
        print("步骤2: 创建字节流")
        stream = bytearray()

        # PGCOPY\n\377\r\n\0 - 二进制COPY的文件签名
        stream.extend(b'PGCOPY\n\377\r\n\0')

        # 写入标志字段 (4个字节的0)
        stream.extend(b'\x00\x00\x00\x00')

        # 写入扩展标头长度 (4个字节的0)
        stream.extend(b'\x00\x00\x00\x00')

        # 开始写入元组
        print("步骤3: 开始处理向量")
        for i, sparse_vec in enumerate(sparse_vectors):
            # 字段数量 (每个元组1个字段: vec) - 使用网络字节序
            stream.extend(struct.pack('!h', 1))

            # 对vec字段，直接使用SparseVector对象的getbinary()方法获取二进制表示
            binary_vec = sparse_vec.getbinary()
            stream.extend(struct.pack('!i', len(binary_vec)))
            stream.extend(binary_vec)

        # 写入文件尾部标记 (-1)，使用网络字节序
        stream.extend(struct.pack('!h', -1))

        # 创建一个BytesIO对象并写入数据
        bio = io.BytesIO(stream)

        # 执行二进制COPY操作
        curs = self.conn.cursor()
        try:
            curs.copy_expert("COPY sparsevector_test (vec) FROM STDIN WITH BINARY", bio)
            self.conn.commit()

            # 验证数据
            curs.execute("SELECT COUNT(*) FROM sparsevector_test")
            count = curs.fetchone()[0]
            print(f"表中记录总数: {count}")

            # 获取一条记录作为示例
            curs.execute("SELECT id, vec FROM sparsevector_test LIMIT 1")
            sample = curs.fetchone()
            print(f"示例记录: {sample}")
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def generate_random_sparse_vectors(self, num_vectors, dimension, sparsity=0.1):
        """生成随机稀疏向量，sparsity表示非零元素的比例"""
        sparse_vectors = []
        for _ in range(num_vectors):
            # 计算非零元素数量
            non_zero_count = max(1, int(dimension * sparsity))

            # 生成随机索引（确保不重复）
            indices = random.sample(range(dimension), non_zero_count)
            indices.sort()

            # 创建字典形式的稀疏向量
            vec_dict = {}
            for idx in indices:
                vec_dict[idx] = random.uniform(-10.0, 10.0)

            # 创建SparseVector对象
            sparse_vectors.append(SparseVector((vec_dict, dimension)))
        return sparse_vectors


def test_suite():
    return unittest.TestLoader().loadTestsFromName(__name__)


if __name__ == "__main__":
    unittest.main()
