#!/usr/bin/env python
#
# test_int8vector.py - tests for int8vector types conversions
#
# Copyright (C) 2004-2019 Federico Di Gregorio  <fog@debian.org>
# Copyright (C) 2020-2021 The Psycopg Team
#
# psycopg2 is free software: you can redistribute it and/or modify it
# under the terms of the GNU Lesser General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# In addition, as a special exception, the copyright holders give
# permission to link this program with the OpenSSL library (or with
# modified versions of OpenSSL that use the same license as OpenSSL),
# and distribute linked combinations including the two.
#
# You must obey the GNU Lesser General Public License in all respects for
# all of the code used other than OpenSSL.
#
# psycopg2 is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
# License for more details.

import io
import random
import unittest
# import testutils
import struct
from typing import Any
from .testutils import ConnectingTestCase

import psycopg2
from psycopg2.extensions import Int8Vector


class TestInt8Vector(ConnectingTestCase):
    """测试 psycopg2.extensions.Int8Vector 类型"""

    def setUp(self):
        """设置测试环境"""
        super(TestInt8Vector, self).setUp()

        # 创建测试表
        cur = self.conn.cursor()
        try:
            cur.execute("DROP TABLE IF EXISTS int8vector_test;")
            cur.execute("CREATE TABLE int8vector_test (id serial PRIMARY KEY, vec int8vector);")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            cur.close()

    def tearDown(self):
        """清理测试环境"""
        # 确保任何未完成的事务被回滚
        self.conn.rollback()

        cur = self.conn.cursor()
        try:
            cur.execute("DROP TABLE IF EXISTS int8vector_test;")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
        finally:
            cur.close()

        super(TestInt8Vector, self).tearDown()

    def test_constructor_with_list(self):
        """测试使用列表构造 Int8Vector"""
        int_list = [1, 2, 3, -4]
        vec = Int8Vector(int_list)

        self.assertEqual(vec.tolist(), int_list)
        self.assertEqual(len(vec), len(int_list))

    def test_constructor_with_tuple(self):
        """测试使用元组构造 Int8Vector"""
        int_tuple = (1, 2, 3, -4)
        vec = Int8Vector(int_tuple)

        self.assertEqual(vec.tolist(), list(int_tuple))
        self.assertEqual(len(vec), len(int_tuple))

    def test_empty_vector(self):
        """测试构造空向量"""
        vec = Int8Vector([])

        self.assertEqual(vec.tolist(), [])
        self.assertEqual(len(vec), 0)

    def test_write_int8vector_to_database(self):
        """测试将 Int8Vector 对象写入数据库"""
        int_list = [1, 2, 3, -4]
        vec = Int8Vector(int_list)

        curs = self.conn.cursor()
        try:
            curs.execute("INSERT INTO int8vector_test (vec) VALUES (%s) RETURNING id;", (vec,))
            row_id = curs.fetchone()[0]

            # 验证插入成功
            curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]
            print(f"预期向量，ID: {row_id}, 向量: {result}")
            self.assertIsInstance(result, Int8Vector)
            self.assertEqual(result.tolist(), int_list)
            self.assertEqual(len(result), len(int_list))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    # def test_write_list_to_database(self):
    #     """直接使用 Python list 对象写入数据库"""
    #     int_list = [1, 2, 3, -4]

    #     curs = self.conn.cursor()
    #     try:
    #         curs.execute("INSERT INTO int8vector_test (vec) VALUES (%s) RETURNING id;", (int_list,))
    #         row_id = curs.fetchone()[0]

    #         # 验证插入成功
    #         curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
    #         result = curs.fetchone()[0]

    #         self.assertIsInstance(result, Int8Vector)
    #         self.assertEqual(result.tolist(), int_list)
    #         self.conn.commit()
    #     except Exception:
    #         self.conn.rollback()
    #         raise
    #     finally:
    #         curs.close()

    def test_write_bracket_string_to_database(self):
        """测试使用 [1,2,3] 格式的字符串写入数据库"""
        int_list = [1, 2, 3]
        string_repr = "[1,2,3]"

        curs = self.conn.cursor()
        try:
            curs.execute("INSERT INTO int8vector_test (vec) VALUES (%s) RETURNING id;", (string_repr,))
            row_id = curs.fetchone()[0]

            # 验证插入成功
            curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, Int8Vector)
            self.assertEqual(result.tolist(), int_list)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    # def test_write_array_string_to_database(self):
    #     """测试使用 ARRAY[1,2,3]::int8vector 格式的字符串写入数据库"""
    #     int_list = [1, 2, 3]
    #     string_repr = "ARRAY[1,2,3]::int8vector"

    #     curs = self.conn.cursor()
    #     try:
    #         # 这里直接将字符串放入 SQL 语句，而不是参数化
    #         curs.execute(f"INSERT INTO int8vector_test (vec) VALUES ({string_repr}) RETURNING id;")
    #         row_id = curs.fetchone()[0]

    #         # 验证插入成功
    #         curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
    #         result = curs.fetchone()[0]

    #         self.assertIsInstance(result, Int8Vector)
    #         self.assertEqual(result.tolist(), int_list)
    #         self.conn.commit()
    #     except Exception:
    #         self.conn.rollback()
    #         raise
    #     finally:
    #         curs.close()

    # def test_read_from_database(self):
    #     """测试从数据库读取 Int8Vector"""
    #     int_list = [1, 2, 3, -4]

    #     curs = self.conn.cursor()
    #     try:
    #         # 使用数组语法直接插入
    #         curs.execute("INSERT INTO int8vector_test (vec) VALUES (ARRAY[%s, %s, %s, %s]::int8vector) RETURNING id;", int_list)
    #         row_id = curs.fetchone()[0]

    #         # 读取并验证
    #         curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
    #         result = curs.fetchone()[0]

    #         self.assertIsInstance(result, Int8Vector)
    #         self.assertEqual(result.tolist(), int_list)
    #         self.assertEqual(len(result), len(int_list))
    #         self.conn.commit()
    #     except Exception:
    #         self.conn.rollback()
    #         raise
    #     finally:
    #         curs.close()

    def test_different_dimensions(self):
        """测试不同维度的向量"""
        test_vectors = [
            [1],
            [1, 2],
            [1, 2, 3],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        ]

        curs = self.conn.cursor()
        try:
            for vec_list in test_vectors:
                vec = Int8Vector(vec_list)

                curs.execute("INSERT INTO int8vector_test (vec) VALUES (%s) RETURNING id;", (vec,))
                row_id = curs.fetchone()[0]

                curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
                result = curs.fetchone()[0]

                self.assertIsInstance(result, Int8Vector)
                self.assertEqual(result.tolist(), vec_list)
                self.assertEqual(len(result), len(vec_list))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_int8_range(self):
        """测试 int8 的范围 (-128 to 127)"""
        # int8 的范围是 -128 到 127
        test_vectors = [
            [-128, -100, 0, 100, 127],  # 边界值
            [127, 127, 127],            # 最大值
            [-128, -128, -128],         # 最小值
            [0, 0, 0],                  # 零值
        ]

        curs = self.conn.cursor()
        try:
            for vec_list in test_vectors:
                vec = Int8Vector(vec_list)

                curs.execute("INSERT INTO int8vector_test (vec) VALUES (%s) RETURNING id;", (vec,))
                row_id = curs.fetchone()[0]

                curs.execute("SELECT vec FROM int8vector_test WHERE id = %s;", (row_id,))
                result = curs.fetchone()[0]

                self.assertIsInstance(result, Int8Vector)
                self.assertEqual(result.tolist(), vec_list)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    # def test_type_conversion(self):
    #     """测试类型转换处理"""
    #     # 测试浮点数应该被转换为整数
    #     float_list = [1.0, 2.5, 3.7]
    #     vec = Int8Vector(float_list)

    #     # 应该转换为整数
    #     expected = [int(x) for x in float_list]
    #     self.assertEqual(vec.tolist(), expected)

    #     # 测试混合类型列表
    #     mixed_list = [1, 2, 3.0, 4]
    #     vec = Int8Vector(mixed_list)

    #     expected = [int(x) for x in mixed_list]
    #     self.assertEqual(vec.tolist(), expected)

    def test_invalid_inputs(self):
        """测试无效输入"""
        invalid_inputs = [
            (None, "None"),
            (123, "整数"),
            ("string", "字符串"),
            (["a", "b", "c"], "字符串列表"),
        ]

        for invalid_input, desc in invalid_inputs:
            try:
                vec = Int8Vector(invalid_input)
                print(f"注意: Int8Vector 接受 {desc} 作为输入，结果为: {vec}")
            except Exception as e:
                print(f"处理 {desc} 时抛出异常: {type(e).__name__}: {str(e)}")

    def test_unsupported_string_formats(self):
        """测试不支持的字符串格式"""
        unsupported_formats = [
            "'{1,2,3}'",  # PostgreSQL 数组语法
            "(1,2,3)"     # 元组语法
        ]

        for fmt in unsupported_formats:
            curs = self.conn.cursor()
            try:
                # 直接执行 SQL，因为这些格式应该会失败
                with self.assertRaises(Exception):
                    curs.execute(f"INSERT INTO int8vector_test (vec) VALUES ({fmt}::int8vector);")
                self.conn.rollback()  # 即使预期会失败，也需要回滚事务
            except Exception:
                self.conn.rollback()
                raise
            finally:
                curs.close()

    def test_adapter_and_typecast(self):
        """测试 Int8Vector 的适配器和类型转换功能"""
        int_list = [1, 2, 3, -4]
        vec = Int8Vector(int_list)

        # 测试适配器
        adapted = psycopg2.extensions.adapt(vec)
        self.assertIsNotNone(adapted)

        # 检查适配后的结果
        serialized = adapted.getquoted()
        self.assertIsNotNone(serialized)

        # 验证查询结果是否正确转换为 Int8Vector 类型
        curs = self.conn.cursor()
        try:
            curs.execute("SELECT %s::int8vector AS vec", (vec,))
            result = curs.fetchone()[0]

            self.assertIsInstance(result, Int8Vector)
            self.assertEqual(result.tolist(), int_list)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_str_representation(self):
        """测试 str() 表示形式"""
        int_list = [1, 2, 3]
        vec = Int8Vector(int_list)

        # 测试 str() 返回格式为 [1,2,3]
        expected_str = "[1,2,3]"
        self.assertEqual(str(vec), expected_str)

    def test_repr_representation(self):
        """测试 repr() 表示形式"""
        int_list = [1, 2, 3]
        vec = Int8Vector(int_list)

        # 测试 repr() 返回格式为 ARRAY[1,2,3]::int8vector
        expected_repr = "'[1,2,3]'::int8vector"
        self.assertEqual(repr(vec), expected_repr)

        # 额外测试 repr() 是否可以直接用于 SQL
        curs = self.conn.cursor()
        try:
            sql = f"SELECT {repr(vec)};"
            curs.execute(sql)
            result = curs.fetchone()[0]

            self.assertIsInstance(result, Int8Vector)
            self.assertEqual(result.tolist(), int_list)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def test_copy_binary(self):
        """使用COPY WITH BINARY将向量数据复制到PostgreSQL"""
        print("步骤1: 生成向量数据")
        int8_vectors = self.generate_random_vectors(100, 10000)

        # 准备二进制数据
        print("步骤2: 创建字节流")
        stream = bytearray()

        # PGCOPY\n\377\r\n\0 - 二进制COPY的文件签名
        stream.extend(b'PGCOPY\n\377\r\n\0')

        # 写入标志字段 (4个字节的0)
        stream.extend(b'\x00\x00\x00\x00')

        # 写入扩展标头长度 (4个字节的0)
        stream.extend(b'\x00\x00\x00\x00')

        # 开始写入元组
        print("步骤3: 开始处理向量")
        for i, int8_vec in enumerate(int8_vectors):
            # 字段数量 (每个元组1个字段: vec) - 使用网络字节序
            stream.extend(struct.pack('!h', 1))

            # 对vec字段，直接使用Int8Vector对象的getbinary()方法获取二进制表示
            binary_vec = int8_vec.getbinary()
            stream.extend(struct.pack('!i', len(binary_vec)))
            stream.extend(binary_vec)

        # 写入文件尾部标记 (-1)，使用网络字节序
        stream.extend(struct.pack('!h', -1))

        # 创建一个BytesIO对象并写入数据
        bio = io.BytesIO(stream)

        # 执行二进制COPY操作
        curs = self.conn.cursor()
        try:
            curs.copy_expert("COPY int8vector_test (vec) FROM STDIN WITH BINARY", bio)
            self.conn.commit()

            # 验证数据
            curs.execute("SELECT COUNT(*) FROM int8vector_test")
            count = curs.fetchone()[0]
            print(f"表中记录总数: {count}")

            # 获取一条记录作为示例
            curs.execute("SELECT id, vec FROM int8vector_test LIMIT 1")
            sample = curs.fetchone()
            print(f"示例记录: {sample}")
        except Exception:
            self.conn.rollback()
            raise
        finally:
            curs.close()

    def generate_random_vectors(self, num_vectors, dimension):
        """使用Python标准库random生成随机int8向量"""
        int8_vectors = []
        for _ in range(num_vectors):
            # 生成随机整数列表作为向量（范围 -128 到 127）
            vec = [random.randint(-128, 127) for _ in range(dimension)]
            # 创建Int8Vector对象
            int8_vectors.append(Int8Vector(vec))
        return int8_vectors


def test_suite():
    return unittest.TestLoader().loadTestsFromName(__name__)


if __name__ == "__main__":
    unittest.main()
