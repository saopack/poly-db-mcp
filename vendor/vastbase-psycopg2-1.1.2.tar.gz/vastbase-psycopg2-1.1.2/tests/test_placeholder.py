#!/usr/bin/env python

import os
import sys
import psycopg2


def connectVastbase():
    conn=psycopg2.connect(database="postgres",user="vastbase",password="gauss@123",host="127.0.0.1",port="25636")
    print('connect sucessful!')
    cursor = conn.cursor()
    cursor.execute("drop table if exists test_var;")
    cursor.execute("create table test_var(id int, name text);")
    print('create table test_var successful')

    print('****************** :var + execute + dict **************')
    print('------ insert -----')
    params1 = {'name': 'Anna','id': 1}
    params2 = {'name': 'Jack','id': 2}
    sql = "insert into test_var(id,name) values(:id, :name)"
    cursor.execute(sql, params1)
    cursor.execute(sql, params2)
    conn.commit()
    sql = "select a.* from test_var a where id = :id and name = :name"
    cursor.execute(sql, params1)
    record = cursor.fetchone()
    print('fetchone: id = ' + str(record[0]) + ', name = ' + str(record[1]))

    print('------ update -----')
    params = {'id': 2,'name': 'Anna',}
    sql = "update test_var set id = :id where name = :name"
    cursor.execute(sql, params)
    conn.commit()
    sql = "select * from test_var where name = (:name) and id = (:id)"
    cursor.execute(sql, params)
    record = cursor.fetchone()
    print('fetchone: id = ' + str(record[0]) + ', name = ' + str(record[1]))

    print('------ delete -----')
    print('before delete:')
    params = {'id': 2,'name': 'Anna',}
    sql_select = "select * from test_var where id = (:id)"
    cursor.execute(sql_select, params)
    records = cursor.fetchmany(10)
    for record in records:
        print('fetchall: id = ' + str(record[0]) + ', name = ' + str(record[1]))
    sql = "delete from test_var where id = :id and name = :name"
    cursor.execute(sql, params)
    conn.commit()
    print('after delete:')
    sql = "select * from test_var where id = (:id)"
    cursor.execute(sql, params)
    records = cursor.fetchmany(10)
    for record in records:
        print('fetchall: id = ' + str(record[0]) + ', name = ' +  str(record[1]))

    print('****************** :var + executemany + dict **************')
    sql = "insert into test_var(id,name) values(:id, :name)"
    param = {'id': 3,'name': 'Lisa'}
    cursor.executemany(sql, param)
    cursor.execute("select * from test_var where id = :id and name = :name", param)
    record = cursor.fetchone()
    print('fetchone: id = ' + str(record[0]) + ', name = ' + str(record[1]))

    print('****************** :var + executemany + list **************')
    params = [{'id': 4,'name': 'Nancy'}, {'name': 'Rose','id': 5}]
    sql = "insert into test_var(id,name) values(:id, :name)"
    cursor.executemany(sql, params)
    cursor.execute("select * from test_var")
    records = cursor.fetchmany(10)
    for record in records:
        print('fetchall: id = ' + str(record[0]) + ', name = ' +  str(record[1]))

    print('******************create table dtype_test *************')
    cursor.execute("drop table if exists dtype_test;")
    cursor.execute("create table dtype_test(c1 int, c2 int);")
    cursor.execute("insert into dtype_test(c1,c2) values(2,3)")
    conn.commit()
    cursor.execute("select * from dtype_test")
    records = cursor.fetchmany(10)
    for record in records:
        print('fetchall: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]))

    print('******************test execute*************')
    sql = "insert into dtype_test(c1,c2) values(:0,:1)"
    params = ['10','11']
    cursor.execute(sql, params)
    sql = "insert into dtype_test(c1,c2) values(:c1, :c2)"
    params = {'c1':'12','c2':'13'}
    cursor.execute(sql, params)
    params = ['14','15']
    cursor.execute(sql, params)
    sql = "select * from dtype_test where c1 = :c1 and c2 = :c2"
    cursor.execute(sql, params)
    records = cursor.fetchmany(30)
    for record in records:
        print('fetchall: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]))

    print('******************test executemany*************')
    sql = "insert into dtype_test(c1,c2) values(:0,:1)"
    params = [['20','21'],['22','23']]
    cursor.executemany(sql, params)
    sql = "insert into dtype_test(c1,c2) values(:c1, :c2)"
    params = {'c1':'24','c2':'25'}
    cursor.executemany(sql, params)
    params = [{'c1':'26','c2':'27'},{'c1':'28','c2':'29'}]
    cursor.executemany(sql, params)
    params = [['20','21'],['22','23']]
    cursor.executemany(sql, params)

    print('******************test prepare + execute *************')
    sql = "insert into dtype_test(c1,c2) values(:0,:1)"
    params = ['30','31']
    cursor.prepare(sql)
    cursor.execute(None, params)
    cursor.execute(None, params)
    sql = "insert into dtype_test(c1,c2) values(:c1, :c2)"
    params = {'c1':'32','c2':'33'}
    cursor.prepare(sql)
    cursor.execute(None, params)
    cursor.execute(None, params)
    params = ['34','35']
    cursor.prepare(sql)
    cursor.execute(None, params)

    print('******************test prepare + executemany*************')
    sql = "insert into dtype_test(c1,c2) values(:0,:1)"
    params = [['40','41'],['42','43']]
    cursor.prepare(sql)
    cursor.executemany(None, params)
    cursor.executemany(None, params)
    sql = "insert into dtype_test(c1,c2) values(:c1, :c2)"
    params = {'c1':'44','c2':'45'}
    cursor.prepare(sql)
    cursor.executemany(None, params)
    cursor.executemany(None, params)
    params = [{'c1':'46','c2':'47'},{'c1':'48','c2':'49'}]
    cursor.prepare(sql)
    cursor.executemany(None, params)
    cursor.executemany(None, params)
    params = [['46','47'],['48','49']]
    cursor.prepare(sql)
    cursor.executemany(None, params)

    cursor.execute("select * from dtype_test ")
    records = cursor.fetchmany(50)
    for record in records:
        print('fetchall: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]))

    print('******************test :var*************')
    sql = "insert into dtype_test(c2,c1) values(:c2, :c1)"
    params = {'c1':'50','c2':'51'}
    cursor.execute(sql, params)
    params = {'c2':'53','c1':'52'}
    cursor.execute(sql, params)
    params = {'c1':50,'c2':53}
    cursor.execute("select * from dtype_test where c2 = :c2 or c1 = :c1", params)
    records = cursor.fetchmany(30)
    for record in records:
        print('fetchall: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]))
    cursor.execute("select * from dtype_test where c2 = :c2 or c1 = :c2", params)
    records = cursor.fetchmany(30)
    for record in records:
        print('fetchall: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]))

    print('***************special check***********')
    cursor.execute("drop table if exists test_special;")
    cursor.execute("create table test_special(id int, name text);")
    print('create table test_special successful')
    # 强制类型转换
    cursor.execute("insert into test_special(id,name) values(1::int, 'Anna')")
    # 字符串中带:
    cursor.execute("insert into test_special(id,name) values(2, 'An:na')")
    # 注释中的:
    params = {'name': 'Lucy','id': 3}
    cursor.execute("/*/* hint: index only */*/insert into test_special(id,name) values(:id, :name)", params)
    cursor.execute("select * from test_special")
    records = cursor.fetchmany(20)
    for record in records:
        print('fetchall: id = ' + str(record[0]) + ', name = ' +  str(record[1]))
    cursor.execute("declare v int;"
                    "begin v:=v+1; end;")

    print('***************plain percent check***********')
    cursor.execute("drop table if exists test_error;")
    cursor.execute("create table test_error(c1 int, c2 int, c3 text);")
    print('-----:0 + %-----')
    pramas=['1','2']
    sql="insert into test_error values (:0, :1, 'final')"
    cursor.execute(sql, pramas)
    # sql="insert into test_error values (:0, :1, '100%%')"
    sql="insert into test_error values (:0, :1, '100%')"
    cursor.execute(sql, pramas)
    # sql="insert into test_error values (%s, %s, '100%%%%similar''haha''')"
    sql="insert into test_error values (:0, :1, '100%%similar''haha''')"
    cursor.execute(sql, pramas)
    # sql="insert into test_error values (%s, %s, '\"100%%%%similar\"')"
    sql="insert into test_error values (:0, :1, '\"100%%similar\"')"
    cursor.execute(sql, pramas)
    # sql="select * from test_error where c1 = %s and c2 = %s and c3 like 'f%%'"
    sql="select * from test_error where c1 = :0 and c2 = :1 and c3 like 'f%'"
    cursor.execute(sql, pramas)
    record = cursor.fetchone()
    print('fetchone: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]) + ' c3 = ' +  str(record[2]))
    # sql="select * from test_error where c1 = %s and c2 = %s and c3 = '100%%'"
    sql="select * from test_error where c1 = :0 and c2 = :1 and c3 = '100%'"
    cursor.execute(sql, pramas)
    record = cursor.fetchone()
    print('fetchone: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]) + ' c3 = ' +  str(record[2]))
    pramas=[['3','4'],['5','6']]
    # sql="insert into test_error values (%s, %s, '%%s')"
    sql="insert into test_error values (:0, :1, '%s')"
    cursor.executemany(sql, pramas)
    cursor.execute("select * from test_error")
    records = cursor.fetchmany(20)
    for record in records:
        print('fetchall:c1 = ' + str(record[0]) + ', c2 = ' + str(record[1]) + ' c3 = ' + str(record[2]))

    print('-----:var + %-----')
    pramas=[{'c1':'7', 'c2':'8'},{'c1':'9', 'c2':'10'}]
    # sql="insert into test_error values (%(c1)s, %(c2)s, 'fi%%si')"
    sql="insert into test_error values (:c1, :c2, 'fi%si')"
    cursor.executemany(sql, pramas)
    pramas={'c1':'7', 'c2':'8'}
    # sql="select * from test_error where c3 like 'f%%' and c1 = %(c1)s and c2 = %(c2)s "
    sql="select * from test_error where c3 like 'f%' and c1 = :c1 and c2 = :c2 "
    cursor.execute(sql, pramas)
    record = cursor.fetchone()
    print('fetchone: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]) + ' c3 = ' +  str(record[2]))
    # sql="select * from test_error where c3 = 'fi%%si' and c1 = %(c1)s and c2 = %(c2)s "
    sql="select * from test_error where c3 = 'fi%si' and c1 = :c1 and c2 = :c2 "
    cursor.execute(sql, pramas)
    record = cursor.fetchone()
    print('fetchone: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]) + ' c3 = ' +  str(record[2]))
    # sql="select * from test_error where c1 = %(c1)s %% 10"
    sql="select * from test_error where c1 = :c1 % 10"
    pramas={'c1':'7'}
    cursor.execute(sql, pramas)
    record = cursor.fetchone()
    print('fetchone: c1 = ' + str(record[0]) + ', c2 = ' +  str(record[1]) + ' c3 = ' +  str(record[2]))

    print('-----normal test-----')
    cursor.execute("drop table if exists \"''n%s\";")
    cursor.execute("create table \"''n%s\"(\"c%1\" int, c2 int, c3 text);")
    sql = "insert into \"''n%s\" values (1, 2, '100%')"
    cursor.execute(sql)
    pramas=['1','2']
    # sql = "insert into \"n%%s\" values (:0, :1, '100%%')"
    sql = "insert into \"''n%s\" values (:0, :1, '100%')"
    cursor.execute(sql, pramas)
    # sql = "select * from \"n%%s\" where \"c%%1\" = :0 and c2 = :1 and c3 = '100%%' "
    sql = "select * from \"''n%s\" where \"c%1\" = :0 and c2 = :1 and c3 = '100%' "
    cursor.execute(sql, pramas)
    records = cursor.fetchmany(20)
    for record in records:
        print('fetchall: \"c%1\" = ' + str(record[0]) + ', c2 = ' + str(record[1]) + ' c3 = ' + str(record[2]))


    cursor.close()
    conn.close()


if __name__=='__main__':
    connectVastbase()