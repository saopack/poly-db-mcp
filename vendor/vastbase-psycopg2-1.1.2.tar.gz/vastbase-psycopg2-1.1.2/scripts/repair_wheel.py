#!/usr/bin/env python3
"""
Custom wheel repair script for openGauss-connector-python-psycopg2.

This script replaces auditwheel repair with a patchelf-based approach that:
1. Extracts the wheel to a temporary directory
2. Copies openGauss libraries from /tmp/opengauss-libs
3. Sets RPATH for bundled libraries to ensure they can find each other
4. Repacks the wheel with all dependencies bundled
"""

import os
import sys
import zipfile
import shutil
import tempfile
import subprocess
import argparse
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def run_command(cmd, check=True):
    """Run a command and return the result."""
    logger.info(f"Running: {cmd}")
    # Python 3.6 doesn't support capture_output and text, use stdout/stderr and decode manually
    result = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    if check and result.returncode != 0:
        logger.error(f"Command failed: {cmd}")
        logger.error(f"stderr: {result.stderr}")
        raise subprocess.CalledProcessError(result.returncode, cmd)
    return result

def find_libraries_to_bundle(wheel_dir):
    """
    Find all shared libraries in the wheel that need RPATH adjustment.
    Returns a list of library file paths.
    """
    libraries = []
    for root, dirs, files in os.walk(wheel_dir):
        for file in files:
            if file.endswith('.so'):
                lib_path = os.path.join(root, file)
                libraries.append(lib_path)
    return libraries

def repair_wheel(wheel_path, dest_dir):
    """
    Repair a wheel by bundling openGauss libraries and setting proper RPATH.

    Args:
        wheel_path: Path to the input wheel file
        dest_dir: Directory where the repaired wheel should be placed
    """
    wheel_path = Path(wheel_path)
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Create temporary directory for wheel extraction
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        extract_dir = temp_path / "extracted"
        extract_dir.mkdir()

        # Extract the wheel
        logger.info(f"Extracting wheel {wheel_path}")
        with zipfile.ZipFile(wheel_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)

        # Copy openGauss libraries to the wheel
        libs_source = Path("/tmp/opengauss-libs")
        if libs_source.exists():
            libs_dest = extract_dir / "psycopg2" / "libs"
            libs_dest.mkdir(parents=True, exist_ok=True)

            logger.info(f"Copying libraries from {libs_source} to {libs_dest}")
            for lib_file in libs_source.glob("*.so*"):
                dest_lib = libs_dest / lib_file.name
                shutil.copy2(lib_file, dest_lib)
                logger.info(f"Copied {lib_file.name}")

                # Set RPATH for bundled library to look in the libs directory
                run_command(f"patchelf --set-rpath '$ORIGIN' {dest_lib}")

        # Find all libraries in the wheel and update their RPATH
        libraries = find_libraries_to_bundle(extract_dir)

        for lib_path in libraries:
            # Set RPATH to include the libs directory
            rel_path = Path(lib_path).relative_to(extract_dir)
            lib_dir = Path(lib_path).parent
            rpath_entries = []

            # Add $ORIGIN for the library itself
            rpath_entries.append("$ORIGIN")

            # If this is not in the libs directory, add path to libs
            if "libs" not in str(rel_path):
                # Calculate relative path to libs directory
                depth = len(rel_path.parts) - 1
                rel_libs_path = "/".join([".."] * depth) + "/psycopg2/libs"
                rpath_entries.append(f"$ORIGIN/{rel_libs_path}")

            rpath = ":".join(rpath_entries)

            # Set the RPATH
            run_command(f"patchelf --set-rpath '{rpath}' {lib_path}")
            logger.info(f"Updated RPATH for {rel_path}")

        # Update any .so files that might not have proper SONAME
        for lib_path in libraries:
            if "libs" in str(lib_path):
                lib_name = Path(lib_path).name
                # Check if SONAME is set
                result = run_command(f"patchelf --print-soname {lib_path}", check=False)
                if not result.stdout.strip():
                    # Set SONAME to the library name
                    run_command(f"patchelf --set-soname {lib_name} {lib_path}")
                    logger.info(f"Set SONAME for {lib_name}")

        # Repack the wheel
        wheel_name = wheel_path.name
        repaired_wheel_path = dest_dir / wheel_name

        logger.info(f"Repacking wheel to {repaired_wheel_path}")
        with zipfile.ZipFile(repaired_wheel_path, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
            for root, dirs, files in os.walk(extract_dir):
                for file in files:
                    file_path = Path(root) / file
                    arc_path = file_path.relative_to(extract_dir)
                    zip_ref.write(file_path, arc_path)

        logger.info(f"Successfully repaired wheel: {repaired_wheel_path}")
        return repaired_wheel_path

def main():
    parser = argparse.ArgumentParser(description="Repair wheel with openGauss libraries")
    parser.add_argument("wheel", help="Path to the wheel to repair")
    parser.add_argument("dest_dir", help="Directory where repaired wheel should be placed")

    args = parser.parse_args()

    # Check if patchelf is available
    try:
        subprocess.run(["patchelf", "--version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except (subprocess.CalledProcessError, FileNotFoundError):
        logger.error("patchelf is required but not found in PATH")
        sys.exit(1)

    # Check if openGauss libraries are available
    libs_source = Path("/tmp/opengauss-libs")
    if not libs_source.exists():
        logger.error(f"openGauss libraries not found at {libs_source}")
        logger.error("Make sure the cibuildwheel before-all script has run")
        sys.exit(1)

    # Repair the wheel
    try:
        repair_wheel(args.wheel, args.dest_dir)
        logger.info("Wheel repair completed successfully")
    except Exception as e:
        logger.error(f"Failed to repair wheel: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()