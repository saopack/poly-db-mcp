/* adapter_sparsevec.c - psycopg sparsevec type wrapper implementation
 *
 * Copyright (C) 2003-2019 Federico Di Gregorio <fog@debian.org>
 * Copyright (C) 2020-2021 The Psycopg Team
 *
 * This file is part of psycopg.
 *
 * psycopg2 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link this program with the OpenSSL library (or with
 * modified versions of OpenSSL that use the same license as OpenSSL),
 * and distribute linked combinations including the two.
 *
 * You must obey the GNU Lesser General Public License in all respects for
 * all of the code used other than OpenSSL.
 *
 * psycopg2 is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 */

#define PSYCOPG_MODULE
#include "psycopg/psycopg.h"

#include "psycopg/adapter_psparsevector.h"
#include "psycopg/microprotocols_proto.h"

#include <floatobject.h>
#include <longobject.h>
/* htonl(), ntohl() */
#ifdef _WIN32
#include <winsock2.h>
/* gettimeofday() */
#include "psycopg/win32_support.h"
#else
#include <arpa/inet.h>
#endif


/* Helper function to format float using %.7g format */
static PyObject *
format_float_with_g(PyObject *float_obj)
{
    double value;
    char buffer[32];
    int len;

    /* Get the double value */
    value = PyFloat_AsDouble(float_obj);
    if (value == -1.0 && PyErr_Occurred()) {
        return NULL;
    }

    /* Format using %.7g to automatically handle trailing zeros */
    len = PyOS_snprintf(buffer, sizeof(buffer), "%.7g", value);
    if (len < 0 || len >= (int)sizeof(buffer)) {
        PyErr_SetString(PyExc_OverflowError, "float formatting buffer too small");
        return NULL;
    }

    /* Return a new bytes object with the formatted string */
    return Bytes_FromStringAndSize(buffer, len);
}


/* Helper function to validate a single (index, value) pair
 * Returns 1 if valid, 0 otherwise (with exception set)
 */
static int
validate_sparsevec_pair(PyObject *pair, int32_t *out_index, float *out_value, int32_t max_dim)
{
    PyObject *index_obj = NULL;
    PyObject *value_obj = NULL;
    long lval;
    double dval, val;

    /* The pair should be a 2-element sequence */
    if (!PySequence_Check(pair) || PySequence_Size(pair) != 2) {
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec pairs must be 2-element sequences (index, value)");
        return 0;
    }

    /* Get index and value */
    index_obj = PySequence_GetItem(pair, 0);
    value_obj = PySequence_GetItem(pair, 1);

    if (!index_obj || !value_obj) {
        Py_XDECREF(index_obj);
        Py_XDECREF(value_obj);
        return 0;
    }

    /* Validate index is an integer */
    if (!PyLong_Check(index_obj)) {
        Py_DECREF(index_obj);
        Py_DECREF(value_obj);
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec indices must be integers");
        return 0;
    }

    /* Validate value is a float or int */
    if (!PyFloat_Check(value_obj) && !PyLong_Check(value_obj)) {
        Py_DECREF(index_obj);
        Py_DECREF(value_obj);
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec values must be numbers (int or float)");
        return 0;
    }

    /* Check if value is zero */
    val = PyFloat_AsDouble(value_obj);
    if (val == 0.0)
    {
        Py_DECREF(index_obj);
        Py_DECREF(value_obj);
        PyErr_SetString(PyExc_ValueError,
                        "sparsevec values cannot be zero");
        return 0;
    }

    /* Convert and validate index */
    lval = PyLong_AsLong(index_obj);
    Py_DECREF(index_obj);
    if (PyErr_Occurred()) {
        Py_DECREF(value_obj);
        return 0;
    }

    if (lval < 0 || lval >= max_dim) {
        Py_DECREF(value_obj);
        PyErr_SetString(PyExc_ValueError,
                       "sparsevec index out of range");
        return 0;
    }

    *out_index = (int32_t)lval;

    /* Convert and validate value */
    if (PyFloat_Check(value_obj)) {
        dval = PyFloat_AsDouble(value_obj);
    } else {
        dval = (double)PyLong_AsLong(value_obj);
    }
    Py_DECREF(value_obj);

    if (PyErr_Occurred()) {
        return 0;
    }

    /* Check if value is finite */
    if (!isfinite(dval)) {
        PyErr_SetString(PyExc_ValueError,
                       "sparsevec values must be finite numbers");
        return 0;
    }

    *out_value = (float)dval;

    return 1;
}


/** the SparseVec object **/

static PyObject *
psparsevec_quote(psparsevecObject *self)
{
    /* Create string representation in format: '{1:2.5,3:4.7}'::sparsevec */
    PyObject *res = NULL;
    PyObject **indices = NULL;
    PyObject **values = NULL;
    Py_ssize_t bufsize = 0;
    char *buf = NULL, *ptr;
    Py_ssize_t i, len;
    PyObject *pairs = NULL;
    PyObject *max_dim_obj = NULL;
    int32_t max_dim = 0;

    /* Get the dictionary from wrapped object
     * Expected format: (pairs, max_dim) where pairs is dict or list of pairs
     */
    if (!PyTuple_Check(self->wrapped) || PyTuple_Size(self->wrapped) != 2) {
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec must be initialized with (pairs, max_dim) tuple");
        goto exit;
    }

    pairs = PyTuple_GET_ITEM(self->wrapped, 0);
    max_dim_obj = PyTuple_GET_ITEM(self->wrapped, 1);

    if (!PyLong_Check(max_dim_obj)) {
        PyErr_SetString(PyExc_TypeError, "max_dim must be an integer");
        goto exit;
    }

    max_dim = (int32_t)PyLong_AsLong(max_dim_obj);
    if (PyErr_Occurred()) goto exit;

    if (max_dim <= 0) {
        PyErr_SetString(PyExc_ValueError, "max_dim must be positive");
        goto exit;
    }

    /* Convert to list of (index, value) pairs */
    if (PyDict_Check(pairs)) {
        /* Convert dict items to list */
        pairs = PyDict_Items(pairs);
        if (!pairs) goto exit;
    } else {
        Py_INCREF(pairs);
    }

    if (!PyList_Check(pairs) && !PyTuple_Check(pairs)) {
        Py_DECREF(pairs);
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec pairs must be a dict or sequence of pairs");
        goto exit;
    }

    /* Get the sequence length */
    len = PySequence_Size(pairs);
    if (len < 0) {
        Py_DECREF(pairs);
        goto exit;
    }

    if (len == 0) {
        Py_DECREF(pairs);
        PyErr_SetString(PyExc_ValueError,
                       "sparsevec cannot be empty");
        goto exit;
    }

    if (!(indices = PyMem_New(PyObject *, len))) {
        Py_DECREF(pairs);
        PyErr_NoMemory();
        goto exit;
    }
    memset(indices, 0, len * sizeof(PyObject*));

    if (!(values = PyMem_New(PyObject *, len))) {
        Py_DECREF(pairs);
        PyErr_NoMemory();
        goto exit;
    }
    memset(values, 0, len * sizeof(PyObject*));

    /* Process each pair */
    for (i = 0; i < len; i++) {
        PyObject *pair = PySequence_GetItem(pairs, i);
        int32_t index;
        float value;
        PyObject *idx_str;
        PyObject *val_float;

        if (!pair)
            goto cleanup;

        if (!validate_sparsevec_pair(pair, &index, &value, max_dim)) {
            Py_DECREF(pair);
            goto cleanup;
        }
        Py_DECREF(pair);

        /* Convert index to string */
        idx_str = PyUnicode_FromFormat("%d", index);
        if (!idx_str) goto cleanup;
        indices[i] = PyUnicode_AsUTF8String(idx_str);
        Py_DECREF(idx_str);
        if (!indices[i]) goto cleanup;

        /* Convert value to string */
        val_float = PyFloat_FromDouble((double)value);
        if (!val_float) goto cleanup;
        values[i] = format_float_with_g(val_float);
        Py_DECREF(val_float);
        if (!values[i]) goto cleanup;

        bufsize += Bytes_GET_SIZE(indices[i]) + 1 +  /* index + colon */
                   Bytes_GET_SIZE(values[i]) + 1;    /* value + comma */
    }

    Py_DECREF(pairs);

    /* Create the result string */
    if (!(ptr = buf = PyMem_Malloc(bufsize + 32))) {  /* Extra space for formatting */
        PyErr_NoMemory();
        goto exit;
    }

    /* Create the sparse vector syntax */
    *ptr++ = '\'';
    *ptr++ = '{';

    for (i = 0; i < len; i++) {
        Py_ssize_t sl;

        /* Add index */
        sl = Bytes_GET_SIZE(indices[i]);
        memcpy(ptr, Bytes_AS_STRING(indices[i]), sl);
        ptr += sl;

        *ptr++ = ':';

        /* Add value */
        sl = Bytes_GET_SIZE(values[i]);
        memcpy(ptr, Bytes_AS_STRING(values[i]), sl);
        ptr += sl;

        *ptr++ = ',';
    }
    *(ptr - 1) = '}';
    *ptr++ = '\'';

    strcpy(ptr, "::sparsevector");
    ptr += 14;

    res = Bytes_FromStringAndSize(buf, ptr - buf);

cleanup:
    for (i = 0; i < len; i++) {
        Py_XDECREF(indices[i]);
        Py_XDECREF(values[i]);
    }
    PyMem_Free(indices);
    PyMem_Free(values);
    Py_DECREF(pairs);

exit:
    PyMem_Free(buf);

    return res;
}

static PyObject *
psparsevec_string(psparsevecObject *self)
{
    /* Create simple string in format: {1:2.5,3:4.7} */
    PyObject *res = NULL;
    PyObject **indices = NULL;
    PyObject **values = NULL;
    Py_ssize_t bufsize = 0;
    char *buf = NULL, *ptr;
    Py_ssize_t i, len;
    PyObject *pairs = NULL;
    PyObject *max_dim_obj = NULL;
    int32_t max_dim = 0;

    /* Get the dictionary from wrapped object */
    if (!PyTuple_Check(self->wrapped) || PyTuple_Size(self->wrapped) != 2) {
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec must be initialized with (pairs, max_dim) tuple");
        goto exit;
    }

    pairs = PyTuple_GET_ITEM(self->wrapped, 0);
    max_dim_obj = PyTuple_GET_ITEM(self->wrapped, 1);

    if (!PyLong_Check(max_dim_obj)) {
        PyErr_SetString(PyExc_TypeError, "max_dim must be an integer");
        goto exit;
    }

    max_dim = (int32_t)PyLong_AsLong(max_dim_obj);
    if (PyErr_Occurred()) goto exit;

    /* Convert to list of pairs */
    if (PyDict_Check(pairs)) {
        pairs = PyDict_Items(pairs);
        if (!pairs) goto exit;
    } else {
        Py_INCREF(pairs);
    }

    if (!PyList_Check(pairs) && !PyTuple_Check(pairs)) {
        Py_DECREF(pairs);
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec pairs must be a dict or sequence of pairs");
        goto exit;
    }

    /* Get the sequence length */
    len = PySequence_Size(pairs);
    if (len < 0) {
        Py_DECREF(pairs);
        goto exit;
    }

    if (len == 0) {
        Py_DECREF(pairs);
        res = Bytes_FromStringAndSize("{}", 2);
        return res;
    }

    if (!(indices = PyMem_New(PyObject *, len))) {
        Py_DECREF(pairs);
        PyErr_NoMemory();
        goto exit;
    }
    memset(indices, 0, len * sizeof(PyObject*));

    if (!(values = PyMem_New(PyObject *, len))) {
        Py_DECREF(pairs);
        PyErr_NoMemory();
        goto exit;
    }
    memset(values, 0, len * sizeof(PyObject*));

    /* Process each pair */
    for (i = 0; i < len; i++) {
        PyObject *pair = PySequence_GetItem(pairs, i);
        int32_t idx;
        float val;
        PyObject *idx_str;
        PyObject *val_float;

        if (!pair)
            goto cleanup;

        if (!validate_sparsevec_pair(pair, &idx, &val, max_dim)) {
            Py_DECREF(pair);
            goto cleanup;
        }
        Py_DECREF(pair);

        /* Convert index to string */
        idx_str = PyUnicode_FromFormat("%d", idx);
        if (!idx_str) goto cleanup;
        indices[i] = PyUnicode_AsUTF8String(idx_str);
        Py_DECREF(idx_str);
        if (!indices[i]) goto cleanup;

        /* Convert value to string */
        val_float = PyFloat_FromDouble((double)val);
        if (!val_float) goto cleanup;
        values[i] = format_float_with_g(val_float);
        Py_DECREF(val_float);
        if (!values[i]) goto cleanup;

        bufsize += Bytes_GET_SIZE(indices[i]) + 1 +  /* index + colon */
                   Bytes_GET_SIZE(values[i]) + 1;    /* value + comma */
    }

    Py_DECREF(pairs);

    /* Create the result string */
    if (!(ptr = buf = PyMem_Malloc(bufsize + 3))) {  /* Extra space for {} */
        PyErr_NoMemory();
        goto exit;
    }

    /* Create the vector syntax */
    *ptr++ = '{';

    for (i = 0; i < len; i++) {
        Py_ssize_t sl;

        /* Add index */
        sl = Bytes_GET_SIZE(indices[i]);
        memcpy(ptr, Bytes_AS_STRING(indices[i]), sl);
        ptr += sl;

        *ptr++ = ':';

        /* Add value */
        sl = Bytes_GET_SIZE(values[i]);
        memcpy(ptr, Bytes_AS_STRING(values[i]), sl);
        ptr += sl;

        *ptr++ = ',';
    }
    *(ptr - 1) = '}';

    res = Bytes_FromStringAndSize(buf, ptr - buf);

cleanup:
    for (i = 0; i < len; i++) {
        Py_XDECREF(indices[i]);
        Py_XDECREF(values[i]);
    }
    PyMem_Free(indices);
    PyMem_Free(values);
    Py_DECREF(pairs);

exit:
    PyMem_Free(buf);

    return res;
}

static PyObject *
psparsevec_getquoted(psparsevecObject *self, PyObject *args)
{
    return psparsevec_quote(self);
}

static PyObject *
psparsevec_getstring(psparsevecObject *self, PyObject *args)
{
    return psparsevec_string(self);
}

/* Binary header size: 4 bytes reserved 0 + 4 bytes nnz + 4 bytes formated */
#define SPARSEVEC_BINARY_HEADER_SIZE 12

/* Get binary representation of sparse vector:
* [32 bytes reserved 0]|[32 bytes nnz]|[32 bits formated]|
* [nnz * 32 bits indices]|[nnz * 32 bits values]
*/
static PyObject *
psparsevec_getbinary(psparsevecObject *self, PyObject *args)
{
    PyObject *res = NULL;
    char *buf = NULL;
    Py_ssize_t len, i;
    size_t buf_size;
    uint32_t net_unused;
    uint32_t net_nnz;
    uint32_t net_formated;
    PyObject *pair = NULL;
    PyObject *pairs = NULL;
    PyObject *max_dim_obj = NULL;
    int32_t max_dim = 0;
    char *indices_section;
    char *values_section;

    /* Process each pair and sort by index for better compression */
    typedef struct pair_t
    {
        int32_t index;
        float value;
    } pair_t;

    pair_t *pair_array;

    /* Get wrapped object */
    if (!PyTuple_Check(self->wrapped) || PyTuple_Size(self->wrapped) != 2)
    {
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec must be initialized with (pairs, max_dim) tuple");
        return NULL;
    }

    pairs = PyTuple_GET_ITEM(self->wrapped, 0);
    max_dim_obj = PyTuple_GET_ITEM(self->wrapped, 1);

    if (!PyLong_Check(max_dim_obj)) {
        PyErr_SetString(PyExc_TypeError, "max_dim must be an integer");
        return NULL;
    }

    max_dim = (int32_t)PyLong_AsLong(max_dim_obj);
    if (PyErr_Occurred()) return NULL;

    /* Convert to list of pairs */
    if (PyDict_Check(pairs)) {
        pairs = PyDict_Items(pairs);
        if (!pairs) return NULL;
    } else {
        Py_INCREF(pairs);
    }

    if (!PyList_Check(pairs) && !PyTuple_Check(pairs)) {
        Py_DECREF(pairs);
        PyErr_SetString(PyExc_TypeError,
                       "sparsevec pairs must be a dict or sequence of pairs");
        return NULL;
    }

    /* Get the sequence length */
    len = PySequence_Size(pairs);
    if (len < 0) {
        Py_DECREF(pairs);
        return NULL;
    }

    if (len == 0) {
        Py_DECREF(pairs);
        PyErr_SetString(PyExc_ValueError,
                       "sparsevec cannot be empty");
        return NULL;
    }

    /* Calculate buffer size: header + indices + values */
    buf_size = SPARSEVEC_BINARY_HEADER_SIZE + (len * sizeof(int32_t) * 2);

    /* Allocate memory for the buffer */
    if (!(buf = PyMem_Malloc(buf_size))) {
        Py_DECREF(pairs);
        PyErr_NoMemory();
        return NULL;
    }

    /* Initialize the buffer to zeros */
    memset(buf, 0, buf_size);

    /* Write the nnz count (2 bytes) - use network byte order (big endian) */
    net_unused = htonl((int32_t)0);
    memcpy(buf, &net_unused, 4);

    net_nnz = htonl((uint32_t)len);
    memcpy(buf + 4, &net_nnz, 4);

    /* Write the dimension (4 bytes) - use network byte order */
    net_formated = htonl((int32_t)1);
    memcpy(buf + 8, &net_formated, 4);

    /* Set pointers to the data sections */
    indices_section = buf + SPARSEVEC_BINARY_HEADER_SIZE;
    values_section = buf + SPARSEVEC_BINARY_HEADER_SIZE + (len * sizeof(uint32_t));

    pair_array = PyMem_New(pair_t, len);
    if (!pair_array) {
        PyMem_Free(buf);
        Py_DECREF(pairs);
        PyErr_NoMemory();
        return NULL;
    }

    /* Copy pairs to array */
    for (i = 0; i < len; i++) {
        pair = PySequence_GetItem(pairs, i);
        if (!pair) {
            PyMem_Free(pair_array);
            PyMem_Free(buf);
            Py_DECREF(pairs);
            return NULL;
        }

        if (!validate_sparsevec_pair(pair, &pair_array[i].index,
                                    &pair_array[i].value, max_dim)) {
            Py_DECREF(pair);
            PyMem_Free(pair_array);
            PyMem_Free(buf);
            Py_DECREF(pairs);
            return NULL;
        }
        Py_DECREF(pair);
    }

    Py_DECREF(pairs);

    /* Write the pairs to binary format */
    for (i = 0; i < len; i++) {
        uint32_t net_index;
        uint32_t net_value;
        float value;

        /* Convert index to network byte order */
        net_index = htonl((uint32_t)pair_array[i].index);
        memcpy(indices_section + (i * sizeof(uint32_t)), &net_index, sizeof(uint32_t));

        /* Convert value to network byte order using integer representation */
        value = pair_array[i].value;
        memcpy(&net_value, &value, sizeof(float));
        net_value = htonl(net_value);
        memcpy(values_section + (i * sizeof(uint32_t)), &net_value, sizeof(uint32_t));
    }

    PyMem_Free(pair_array);

    /* Create a Python bytes object from the buffer */
    res = Bytes_FromStringAndSize(buf, buf_size);

    /* Free the buffer */
    PyMem_Free(buf);

    return res;
}

static PyObject *
psparsevec_repr(psparsevecObject *self)
{
    return psyco_ensure_text(psparsevec_getquoted(self, NULL));
}

static PyObject *
psparsevec_str(psparsevecObject *self)
{
    return psyco_ensure_text(psparsevec_getstring(self, NULL));
}

static PyObject *
psparsevec_conform(psparsevecObject *self, PyObject *args)
{
    PyObject *res, *proto;

    if (!PyArg_ParseTuple(args, "O", &proto)) return NULL;

    if (proto == (PyObject*)&isqlquoteType)
        res = (PyObject*)self;
    else
        res = Py_None;

    Py_INCREF(res);
    return res;
}

/* Convert SparseVec to Python tuple (pairs, max_dim) */
static PyObject *
psparsevec_totuple(psparsevecObject *self, PyObject *args)
{
    Py_INCREF(self->wrapped);
    return self->wrapped;
}

static Py_ssize_t
psparsevec_length(psparsevecObject *self)
{
    PyObject *pairs = PyTuple_GET_ITEM(self->wrapped, 0);

    if (PyDict_Check(pairs)) {
        return PyDict_Size(pairs);
    }
    else if (PyList_Check(pairs)) {
        return PyList_Size(pairs);
    }
    else if (PyTuple_Check(pairs)) {
        return PyTuple_Size(pairs);
    }
    return 0;
}

/* Sequence methods */
static PySequenceMethods psparsevec_as_sequence = {
    (lenfunc)psparsevec_length,  /* sq_length */
    0,                            /* sq_concat */
    0,                            /* sq_repeat */
    0,                            /* sq_item */
    0,                            /* sq_slice */
    0,                            /* sq_ass_item */
    0,                            /* sq_ass_slice */
    0,                            /* sq_contains */
    0,                            /* sq_inplace_concat */
    0,                            /* sq_inplace_repeat */
};

/** the SparseVec object **/

/* object member list */

static struct PyMemberDef psparsevecObject_members[] = {
    {"adapted", T_OBJECT, offsetof(psparsevecObject, wrapped), READONLY},
    {NULL}
};

/* object method table */

static PyMethodDef psparsevecObject_methods[] = {
    {"getquoted", (PyCFunction)psparsevec_getquoted, METH_NOARGS,
     "getquoted() -> wrapped object value as SQL-quoted string"},
    {"getbinary", (PyCFunction)psparsevec_getbinary, METH_NOARGS,
    "getbinary() -> binary representation of the sparse vector with format:\n"
    "[16 bytes nnz]|[16 bytes reserved zeros]|[32 bits dimension]|\n"
    "[nnz * 32 bits indices]|[nnz * 32 bits values]"},
    {"__conform__", (PyCFunction)psparsevec_conform, METH_VARARGS, NULL},
    {"totuple", (PyCFunction)psparsevec_totuple, METH_NOARGS,
     "totuple() -> returns a copy of the sparse vector as a (pairs, max_dim) tuple"},
    {NULL}  /* Sentinel */
};

/* initialization and finalization methods */

static int
psparsevec_setup(psparsevecObject *self, PyObject *obj)
{
    Dprintf("psparsevec_setup: init sparsevec object at %p, refcnt = "
        FORMAT_CODE_PY_SSIZE_T,
        self, Py_REFCNT(self)
    );

    if (!PyTuple_Check(obj) || PyTuple_Size(obj) != 2)
        return -1;

    Py_INCREF(obj);
    self->wrapped = obj;

    Dprintf("psparsevec_setup: good sparsevec object at %p, refcnt = "
        FORMAT_CODE_PY_SSIZE_T,
        self, Py_REFCNT(self)
    );
    return 0;
}

static int
psparsevec_traverse(psparsevecObject *self, visitproc visit, void *arg)
{
    Py_VISIT(self->wrapped);
    return 0;
}

static int
psparsevec_clear(psparsevecObject *self)
{
    Py_CLEAR(self->wrapped);
    return 0;
}

static void
psparsevec_dealloc(psparsevecObject* self)
{
    PyObject_GC_UnTrack((PyObject *)self);
    psparsevec_clear(self);

    Dprintf("psparsevec_dealloc: deleted sparsevec object at %p, "
        "refcnt = " FORMAT_CODE_PY_SSIZE_T, self, Py_REFCNT(self));

    Py_TYPE(self)->tp_free((PyObject *)self);
}

static int
psparsevec_init(PyObject *obj, PyObject *args, PyObject *kwds)
{
    PyObject *vec_tuple;

    if (!PyArg_ParseTuple(args, "O", &vec_tuple))
        return -1;

    return psparsevec_setup((psparsevecObject *)obj, vec_tuple);
}

static PyObject *
psparsevec_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    return type->tp_alloc(type, 0);
}


/* object type */

#define psparsevectorType_doc \
"SparseVec((pairs, max_dim)) -> new Sparse vector adapter object\n\n" \
"pairs can be:\n" \
"  - A dict: {index: value, ...}\n" \
"  - A list or tuple of pairs: [(index, value), ...]\n" \
"max_dim is the maximum dimension of the vector."

PyTypeObject psparsevectorType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "psycopg2._psycopg.SparseVec",
    sizeof(psparsevecObject), 0,
    (destructor)psparsevec_dealloc, /*tp_dealloc*/
    0,          /*tp_print*/
    0,          /*tp_getattr*/
    0,          /*tp_setattr*/
    0,          /*tp_compare*/
    (reprfunc)psparsevec_repr, /*tp_repr*/
    0,          /*tp_as_number*/
    &psparsevec_as_sequence, /*tp_as_sequence*/
    0,          /*tp_as_mapping*/
    0,          /*tp_hash */
    0,          /*tp_call*/
    (reprfunc)psparsevec_str, /*tp_str*/
    0,          /*tp_getattro*/
    0,          /*tp_setattro*/
    0,          /*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT|Py_TPFLAGS_BASETYPE|Py_TPFLAGS_HAVE_GC, /*tp_flags*/
    psparsevectorType_doc, /*tp_doc*/
    (traverseproc)psparsevec_traverse,          /*tp_traverse*/
    (inquiry)psparsevec_clear,          /*tp_clear*/
    0,          /*tp_richcompare*/
    0,          /*tp_weaklistoffset*/
    0,          /*tp_iter*/
    0,          /*tp_iternext*/
    psparsevecObject_methods, /*tp_methods*/
    psparsevecObject_members, /*tp_members*/
    0,          /*tp_getset*/
    0,          /*tp_base*/
    0,          /*tp_dict*/
    0,          /*tp_descr_get*/
    0,          /*tp_descr_set*/
    0,          /*tp_dictoffset*/
    psparsevec_init, /*tp_init*/
    0,          /*tp_alloc*/
    psparsevec_new, /*tp_new*/
};
