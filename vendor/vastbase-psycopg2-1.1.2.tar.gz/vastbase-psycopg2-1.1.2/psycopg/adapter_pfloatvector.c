/* adapter_pfloatvector.c - psycopg pfloatvector type wrapper implementation
 *
 * Copyright (C) 2003-2019 Federico Di Gregorio <fog@debian.org>
 * Copyright (C) 2020-2021 The Psycopg Team
 *
 * This file is part of psycopg.
 *
 * psycopg2 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link this program with the OpenSSL library (or with
 * modified versions of OpenSSL that use the same license as OpenSSL),
 * and distribute linked combinations including the two.
 *
 * You must obey the GNU Lesser General Public License in all respects for
 * all of the code used other than OpenSSL.
 *
 * psycopg2 is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 */

#define PSYCOPG_MODULE
#include "psycopg/psycopg.h"

#include "psycopg/adapter_pfloatvector.h"
#include "psycopg/microprotocols_proto.h"

#include <floatobject.h>
#include <math.h>
/* htonl(), ntohl() */
#ifdef _WIN32
#include <winsock2.h>
/* gettimeofday() */
#include "psycopg/win32_support.h"
#else
#include <arpa/inet.h>
#endif


/* Helper function to create a nicely formatted float string PyObject 
* Uses %.7g format to automatically simplify floats and remove trailing zeros
*/
static PyObject *
format_float_with_g(PyObject *float_obj)
{
    double value;
    char buffer[32];  /* Should be enough for most floating point values */
    int len;
    
    /* Get the double value */
    value = PyFloat_AsDouble(float_obj);
    if (value == -1.0 && PyErr_Occurred()) {
        return NULL;
    }
    
    /* Format using %.7g to automatically handle trailing zeros */
    len = PyOS_snprintf(buffer, sizeof(buffer), "%.7g", value);
    if (len < 0 || len >= (int)sizeof(buffer)) {
        PyErr_SetString(PyExc_OverflowError, "float formatting buffer too small");
        return NULL;
    }
    
    /* Return a new bytes object with the formatted string */
    return Bytes_FromStringAndSize(buffer, len);
}


/** the FloatVector object **/

static PyObject *
pfloatvector_quote(pfloatvectorObject *self)
{
    /*  adapt the vector by creating string representation of each value
        and then wrapping everything into "ARRAY[]::floatvector" */
    PyObject *res = NULL;
    PyObject **qs = NULL;
    Py_ssize_t bufsize = 0;
    char *buf = NULL, *ptr;
    Py_ssize_t i, len;

    /* Get the sequence length */
    if (PyList_Check(self->wrapped)) {
        len = PyList_GET_SIZE(self->wrapped);
    } else if (PyTuple_Check(self->wrapped)) {
        len = PyTuple_GET_SIZE(self->wrapped);
    } else {
        PyErr_SetString(PyExc_TypeError,
                        "floatvector must be initialized with a list or tuple");
        goto exit;
    }

    /* vectors must not be empty */
    if (len == 0) {
        PyErr_SetString(PyExc_ValueError,
                    "floatvector cannot be empty");
        goto exit;
    }

    if (!(qs = PyMem_New(PyObject *, len))) {
        PyErr_NoMemory();
        goto exit;
    }
    memset(qs, 0, len * sizeof(PyObject *));

    for (i = 0; i < len; i++) {
        PyObject *item;
        double dval;
        
        /* Get the item from the sequence */
        if (PyList_Check(self->wrapped)) {
            item = PyList_GET_ITEM(self->wrapped, i);
        } else {
            item = PyTuple_GET_ITEM(self->wrapped, i);
        }

        /* Check if it's a number (float or int) */
        if (!PyFloat_Check(item) && !PyLong_Check(item)) {
            PyErr_SetString(PyExc_TypeError,
                        "floatvector items must be numbers (float or int)");
            goto exit;
        }
        
        /* Convert to a double to check for NaN/Infinity */
        if (PyFloat_Check(item)) {
            dval = PyFloat_AsDouble(item);
            if (isnan(dval)) {
                PyErr_SetString(PyExc_ValueError,
                            "NaN values are not allowed in vector");
                goto exit;
            }
            else if (isinf(dval)) {
                PyErr_SetString(PyExc_ValueError,
                            "Infinity values are not allowed in vector");
                goto exit;
            }
            
            /* Format float using %.7g format to automatically simplify output */
            qs[i] = format_float_with_g(item);
            if (!qs[i]) goto exit;
        }
        else {
            /* For integers, just convert directly */
            PyObject *str = PyObject_Str(item);
            if (!str) goto exit;
            
            qs[i] = PyUnicode_AsUTF8String(str);
            Py_DECREF(str);
            if (!qs[i]) goto exit;
        }
        
        bufsize += Bytes_GET_SIZE(qs[i]) + 1;  /* this, and a comma */
    }

    /* Create the result string with ARRAY[] syntax */
    if (!(ptr = buf = PyMem_Malloc(bufsize + 21))) {  /* Extra space for "ARRAY[]::floatvector" */
        PyErr_NoMemory();
        goto exit;
    }

    /* Create the ARRAY syntax with floatvector cast */
    strcpy(ptr, "ARRAY[");
    ptr += 6;
    
    for (i = 0; i < len; i++) {
        Py_ssize_t sl;
        sl = Bytes_GET_SIZE(qs[i]);
        memcpy(ptr, Bytes_AS_STRING(qs[i]), sl);
        ptr += sl;

        *ptr++ = ',';
    }
    *(ptr - 1) = ']';

    strcpy(ptr, "::floatvector"); 
    ptr += 13;  /* Length of "::floatvector" */

    res = Bytes_FromStringAndSize(buf, ptr - buf);

exit:
    if (qs) {
        for (i = 0; i < len; i++) {
            PyObject *q = qs[i];
            Py_XDECREF(q);
        }
        PyMem_Free(qs);
    }
    PyMem_Free(buf);

    return res;
}

static PyObject *
pfloatvector_string(pfloatvectorObject *self)
{
    /*  Create a simple string representation of the vector 
        in the format [a, b, c, ...] without type casting */
    PyObject *res = NULL;
    PyObject **qs = NULL;
    Py_ssize_t bufsize = 0;
    char *buf = NULL, *ptr;
    Py_ssize_t i, len;

    /* Get the sequence length */
    if (PyList_Check(self->wrapped)) {
        len = PyList_GET_SIZE(self->wrapped);
    } else if (PyTuple_Check(self->wrapped)) {
        len = PyTuple_GET_SIZE(self->wrapped);
    } else {
        PyErr_SetString(PyExc_TypeError,
                        "floatvector must be initialized with a list or tuple");
        goto exit;
    }

    /* vectors must not be empty */
    if (len == 0) {
        PyErr_SetString(PyExc_ValueError,
                    "floatvector cannot be empty");
        goto exit;
    }

    if (!(qs = PyMem_New(PyObject *, len))) {
        PyErr_NoMemory();
        goto exit;
    }
    memset(qs, 0, len * sizeof(PyObject *));

    for (i = 0; i < len; i++) {
        PyObject *item;
        double dval;
        
        /* Get the item from the sequence */
        if (PyList_Check(self->wrapped)) {
            item = PyList_GET_ITEM(self->wrapped, i);
        } else {
            item = PyTuple_GET_ITEM(self->wrapped, i);
        }

        /* Check if it's a number (float or int) */
        if (!PyFloat_Check(item) && !PyLong_Check(item)) {
            PyErr_SetString(PyExc_TypeError,
                        "floatvector items must be numbers (float or int)");
            goto exit;
        }
        
        /* Convert to a double to check for NaN/Infinity */
        if (PyFloat_Check(item)) {
            dval = PyFloat_AsDouble(item);
            if (isnan(dval)) {
                PyErr_SetString(PyExc_ValueError,
                            "NaN values are not allowed in vector");
                goto exit;
            }
            else if (isinf(dval)) {
                PyErr_SetString(PyExc_ValueError,
                            "Infinity values are not allowed in vector");
                goto exit;
            }
            
            /* Format float using %.7g format to automatically simplify output */
            qs[i] = format_float_with_g(item);
            if (!qs[i]) goto exit;
        }
        else {
            /* For integers, just convert directly */
            PyObject *str = PyObject_Str(item);
            if (!str) goto exit;
            
            qs[i] = PyUnicode_AsUTF8String(str);
            Py_DECREF(str);
            if (!qs[i]) goto exit;
        }
        
        bufsize += Bytes_GET_SIZE(qs[i]) + 1;  /* element, comma */
    }

    /* Create the result string */
    if (!(ptr = buf = PyMem_Malloc(bufsize + 3))) {  /* Extra space for "[]" and null terminator */
        PyErr_NoMemory();
        goto exit;
    }

    /* Create the vector syntax */
    *ptr++ = '[';
    
    for (i = 0; i < len; i++) {
        Py_ssize_t sl;
        sl = Bytes_GET_SIZE(qs[i]);
        memcpy(ptr, Bytes_AS_STRING(qs[i]), sl);
        ptr += sl;
        
        *ptr++ = ',';
    }
    *(ptr - 1) = ']';

    res = Bytes_FromStringAndSize(buf, ptr - buf);

exit:
    if (qs) {
        for (i = 0; i < len; i++) {
            PyObject *q = qs[i];
            Py_XDECREF(q);
        }
        PyMem_Free(qs);
    }
    PyMem_Free(buf);

    return res;
}

static PyObject *
pfloatvector_getquoted(pfloatvectorObject *self, PyObject *args)
{
    return pfloatvector_quote(self);
}

static PyObject *
pfloatvector_getstring(pfloatvectorObject *self, PyObject *args)
{
    return pfloatvector_string(self);
}

/* Binary header size: 2 bytes length + 2 bytes reserved (zeros) */
#define BINARY_HEADER_SIZE 4

/* Get binary representation of vector with format:
* [16 bytes len]|[16 bytes reserved zeros]|[float32 values list]
*/
static PyObject *
pfloatvector_getbinary(pfloatvectorObject *self, PyObject *args)
{
    PyObject *res = NULL;
    char *buf = NULL;
    Py_ssize_t len, i;
    size_t buf_size;
    uint16_t net_len;
    uint32_t net_int;
    PyObject *item = NULL;
    double dval;
    float fval;
    char *data_section;
    
    /* Get the length of the vector */
    if (PyList_Check(self->wrapped)) {
        len = PyList_GET_SIZE(self->wrapped);
    } else if (PyTuple_Check(self->wrapped)) {
        len = PyTuple_GET_SIZE(self->wrapped);
    } else {
        PyErr_SetString(PyExc_TypeError,
                    "floatvector must be initialized with a list or tuple");
        return NULL;
    }
    
    /* vectors must not be empty */
    if (len == 0) {
        PyErr_SetString(PyExc_ValueError,
                    "floatvector cannot be empty");
        return NULL;
    }
    
    /* Calculate buffer size: header + float32 values */
    buf_size = BINARY_HEADER_SIZE + (len * sizeof(float));
    
    /* Allocate memory for the buffer */
    if (!(buf = PyMem_Malloc(buf_size))) {
        PyErr_NoMemory();
        return NULL;
    }
    
    /* Initialize the buffer to zeros */
    memset(buf, 0, buf_size);
    
    /* Write the length (2 bytes) - use network byte order (big endian) */
    net_len = htons((uint16_t)len);
    memcpy(buf, &net_len, 2);
    
    /* The next 2 bytes are reserved and already set to zero */
    
    /* Set pointer to the float data section */
    data_section = buf + BINARY_HEADER_SIZE;
    
    /* Process each vector element */
    for (i = 0; i < len; i++) {
        /* Get the item */
        if (PyList_Check(self->wrapped)) {
            item = PyList_GET_ITEM(self->wrapped, i);
        } else {
            item = PyTuple_GET_ITEM(self->wrapped, i);
        }
        
        /* Check if it's a number (float or int) */
        if (!PyFloat_Check(item) && !PyLong_Check(item)) {
            PyErr_SetString(PyExc_TypeError,
                        "floatvector items must be numbers (float or int)");
            PyMem_Free(buf);
            return NULL;
        }
        
        /* Convert to double and check for invalid values */
        dval = PyFloat_AsDouble(item);
        if (PyErr_Occurred()) {
            PyMem_Free(buf);
            return NULL;
        }
        
        /* Check for NaN/Infinity */
        if (isnan(dval)) {
            PyErr_SetString(PyExc_ValueError,
                        "NaN values are not allowed in vector");
            PyMem_Free(buf);
            return NULL;
        }
        else if (isinf(dval)) {
            PyErr_SetString(PyExc_ValueError,
                        "Infinity values are not allowed in vector");
            PyMem_Free(buf);
            return NULL;
        }
        
        /* Convert double to float32 */
        fval = (float)dval;
        
        /* Convert the float bytes to network byte order (big endian) */
        memcpy(&net_int, &fval, sizeof(float));
        net_int = htonl(net_int);
        
        /* Copy the bytes to the buffer at the correct position */
        memcpy(data_section + (i * sizeof(float)), &net_int, sizeof(float));
    }
    
    /* Create a Python bytes object from the buffer */
    res = Bytes_FromStringAndSize(buf, buf_size);
    
    /* Free the buffer */
    PyMem_Free(buf);
    
    return res;
}

static PyObject *
pfloatvector_repr(pfloatvectorObject *self)
{
    return psyco_ensure_text(pfloatvector_getquoted(self, NULL));
}

static PyObject *
pfloatvector_str(pfloatvectorObject *self)
{
    return psyco_ensure_text(pfloatvector_getstring(self, NULL));
}

static PyObject *
pfloatvector_conform(pfloatvectorObject *self, PyObject *args)
{
    PyObject *res, *proto;

    if (!PyArg_ParseTuple(args, "O", &proto)) return NULL;

    if (proto == (PyObject*)&isqlquoteType)
        res = (PyObject*)self;
    else
        res = Py_None;

    Py_INCREF(res);
    return res;
}

/* Convert FloatVector to Python list */
static PyObject *
pfloatvector_tolist(pfloatvectorObject *self, PyObject *args)
{
    if (PyList_Check(self->wrapped)) {
        Py_INCREF(self->wrapped);
        return self->wrapped;
    } 
    else if (PyTuple_Check(self->wrapped)) {
        /* Convert tuple to list */
        return PySequence_List(self->wrapped);
    }
    
    /* This should never happen as we check in init */
    PyErr_SetString(PyExc_TypeError, "wrapped object is not a sequence");
    return NULL;
}

static Py_ssize_t
pfloatvector_length(pfloatvectorObject *self)
{
    if (PyList_Check(self->wrapped)) {
        return PyList_Size(self->wrapped);
    }
    else if (PyTuple_Check(self->wrapped)) {
        return PyTuple_Size(self->wrapped);
    }
    return 0;
}

/* Sequence methods */
static PySequenceMethods pfloatvector_as_sequence = {
    (lenfunc)pfloatvector_length,  /* sq_length */
    0,                            /* sq_concat */
    0,                            /* sq_repeat */
    0,                            /* sq_item */
    0,                            /* sq_slice */
    0,                            /* sq_ass_item */
    0,                            /* sq_ass_slice */
    0,                            /* sq_contains */
    0,                            /* sq_inplace_concat */
    0,                            /* sq_inplace_repeat */
};

/** the FloatVector object */

/* object member list */

static struct PyMemberDef pfloatvectorObject_members[] = {
    {"adapted", T_OBJECT, offsetof(pfloatvectorObject, wrapped), READONLY},
    {NULL}
};

/* object method table */

static PyMethodDef pfloatvectorObject_methods[] = {
    {"getquoted", (PyCFunction)pfloatvector_getquoted, METH_NOARGS,
     "getquoted() -> wrapped object value as SQL-quoted string"},
    {"getbinary", (PyCFunction)pfloatvector_getbinary, METH_NOARGS,
    "getbinary() -> binary representation of the vector with format:\n"
    "[16 bytes len]|[16 bytes reserved zeros]|[float32 values list]"},
    {"__conform__", (PyCFunction)pfloatvector_conform, METH_VARARGS, NULL},
    {"tolist", (PyCFunction)pfloatvector_tolist, METH_NOARGS,
     "tolist() -> returns a copy of the vector as a Python list"},
    {NULL}  /* Sentinel */
};

/* initialization and finalization methods */

static int
pfloatvector_setup(pfloatvectorObject *self, PyObject *obj)
{
    Dprintf("pfloatvector_setup: init pfloatvector object at %p, refcnt = "
        FORMAT_CODE_PY_SSIZE_T,
        self, Py_REFCNT(self)
    );

    if (!PyList_Check(obj) && !PyTuple_Check(obj))
        return -1;

    Py_INCREF(obj);
    self->wrapped = obj;

    Dprintf("pfloatvector_setup: good pfloatvector object at %p, refcnt = "
        FORMAT_CODE_PY_SSIZE_T,
        self, Py_REFCNT(self)
    );
    return 0;
}

static int
pfloatvector_traverse(pfloatvectorObject *self, visitproc visit, void *arg)
{
    Py_VISIT(self->wrapped);
    return 0;
}

static int
pfloatvector_clear(pfloatvectorObject *self)
{
    Py_CLEAR(self->wrapped);
    return 0;
}

static void
pfloatvector_dealloc(pfloatvectorObject* self)
{
    PyObject_GC_UnTrack((PyObject *)self);
    pfloatvector_clear(self);

    Dprintf("pfloatvector_dealloc: deleted pfloatvector object at %p, "
        "refcnt = " FORMAT_CODE_PY_SSIZE_T, self, Py_REFCNT(self));

    Py_TYPE(self)->tp_free((PyObject *)self);
}

static int
pfloatvector_init(PyObject *obj, PyObject *args, PyObject *kwds)
{
    PyObject *l;

    if (!PyArg_ParseTuple(args, "O", &l))
        return -1;

    return pfloatvector_setup((pfloatvectorObject *)obj, l);
}

static PyObject *
pfloatvector_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    return type->tp_alloc(type, 0);
}


/* object type */

#define pfloatvectorType_doc \
"FloatVector(list) -> new Float vector adapter object"

PyTypeObject pfloatvectorType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "psycopg2._psycopg.FloatVector",
    sizeof(pfloatvectorObject), 0,
    (destructor)pfloatvector_dealloc, /*tp_dealloc*/
    0,          /*tp_print*/
    0,          /*tp_getattr*/
    0,          /*tp_setattr*/
    0,          /*tp_compare*/
    (reprfunc)pfloatvector_repr, /*tp_repr*/
    0,          /*tp_as_number*/
    &pfloatvector_as_sequence, /*tp_as_sequence*/
    0,          /*tp_as_mapping*/
    0,          /*tp_hash */
    0,          /*tp_call*/
    (reprfunc)pfloatvector_str, /*tp_str*/
    0,          /*tp_getattro*/
    0,          /*tp_setattro*/
    0,          /*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT|Py_TPFLAGS_BASETYPE|Py_TPFLAGS_HAVE_GC, /*tp_flags*/
    pfloatvectorType_doc, /*tp_doc*/
    (traverseproc)pfloatvector_traverse,          /*tp_traverse*/
    (inquiry)pfloatvector_clear,          /*tp_clear*/
    0,          /*tp_richcompare*/
    0,          /*tp_weaklistoffset*/
    0,          /*tp_iter*/
    0,          /*tp_iternext*/
    pfloatvectorObject_methods, /*tp_methods*/
    pfloatvectorObject_members, /*tp_members*/
    0,          /*tp_getset*/
    0,          /*tp_base*/
    0,          /*tp_dict*/
    0,          /*tp_descr_get*/
    0,          /*tp_descr_set*/
    0,          /*tp_dictoffset*/
    pfloatvector_init, /*tp_init*/
    0,          /*tp_alloc*/
    pfloatvector_new, /*tp_new*/
};