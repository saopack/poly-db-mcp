/* adapter_int8vector.c - psycopg int8vector type wrapper implementation
 *
 * Copyright (C) 2003-2019 Federico Di Gregorio <fog@debian.org>
 * Copyright (C) 2020-2021 The Psycopg Team
 *
 * This file is part of psycopg.
 *
 * psycopg2 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link this program with the OpenSSL library (or with
 * modified versions of OpenSSL that use the same license as OpenSSL),
 * and distribute linked combinations including the two.
 *
 * You must obey the GNU Lesser General Public License in all respects for
 * all of the code used other than OpenSSL.
 *
 * psycopg2 is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 */

#define PSYCOPG_MODULE
#include "psycopg/psycopg.h"

#include "psycopg/adapter_pint8vector.h"
#include "psycopg/microprotocols_proto.h"

#include <floatobject.h>
#include <longobject.h>
/* htonl(), ntohl() */
#ifdef _WIN32
#include <winsock2.h>
/* gettimeofday() */
#include "psycopg/win32_support.h"
#else
#include <arpa/inet.h>
#endif


/** the Int8Vector object **/

static PyObject *
pint8vector_quote(pint8vectorObject *self)
{
    /*  adapt the vector by creating string representation of each value
        and then wrapping everything into "ARRAY[]::int8vector" */
    PyObject *res = NULL;
    PyObject **qs = NULL;
    Py_ssize_t bufsize = 0;
    char *buf = NULL, *ptr;
    Py_ssize_t i, len;

    /* Get the sequence length */
    if (PyList_Check(self->wrapped)) {
        len = PyList_GET_SIZE(self->wrapped);
    } else if (PyTuple_Check(self->wrapped)) {
        len = PyTuple_GET_SIZE(self->wrapped);
    } else {
        PyErr_SetString(PyExc_TypeError,
                        "int8vector must be initialized with a list or tuple");
        goto exit;
    }

    /* vectors must not be empty */
    if (len == 0) {
        PyErr_SetString(PyExc_ValueError,
                    "int8vector cannot be empty");
        goto exit;
    }

    if (!(qs = PyMem_New(PyObject *, len))) {
        PyErr_NoMemory();
        goto exit;
    }
    memset(qs, 0, len * sizeof(PyObject *));

    for (i = 0; i < len; i++) {
        PyObject *item;
        PyObject *str;
        long lval;

        /* Get the item from the sequence */
        if (PyList_Check(self->wrapped)) {
            item = PyList_GET_ITEM(self->wrapped, i);
        } else {
            item = PyTuple_GET_ITEM(self->wrapped, i);
        }

        /* Check if it's an integer (int or long) */
        if (!PyLong_Check(item)) {
            if (PyFloat_Check(item)) {
                PyErr_SetString(PyExc_TypeError,
                            "int8vector items must be integers (int), not float");
            } else {
                PyErr_SetString(PyExc_TypeError,
                            "int8vector items must be integers");
            }
            goto exit;
        }

        /* Convert to a long to check the range */
        lval = PyLong_AsLong(item);
        if (PyErr_Occurred()) goto exit;

        /* Check if value is within int8 range (-128 to 127) */
        if (lval < -128 || lval > 127) {
            PyErr_SetString(PyExc_ValueError,
                        "int8vector items must be in range -128 to 127");
            goto exit;
        }

        /* Convert the integer to string representation */
        str = PyObject_Str(item);
        if (!str) goto exit;

        qs[i] = PyUnicode_AsUTF8String(str);
        Py_DECREF(str);
        if (!qs[i]) goto exit;

        bufsize += Bytes_GET_SIZE(qs[i]) + 1;  /* this, and a comma */
    }

    /* Create the result string with ARRAY[] syntax */
    if (!(ptr = buf = PyMem_Malloc(bufsize + 21))) {  /* Extra space for "ARRAY[]::int8vector" */
        PyErr_NoMemory();
        goto exit;
    }

    /* Create the ARRAY syntax with int8vector cast */
    strcpy(ptr, "'[");
    ptr += 2;

    for (i = 0; i < len; i++) {
        Py_ssize_t sl;
        sl = Bytes_GET_SIZE(qs[i]);
        memcpy(ptr, Bytes_AS_STRING(qs[i]), sl);
        ptr += sl;

        *ptr++ = ',';
    }
    *(ptr - 1) = ']';

    strcpy(ptr, "'::int8vector");
    ptr += 13;  /* Length of "::int8vector" */

    res = Bytes_FromStringAndSize(buf, ptr - buf);

exit:
    if (qs) {
        for (i = 0; i < len; i++) {
            PyObject *q = qs[i];
            Py_XDECREF(q);
        }
        PyMem_Free(qs);
    }
    PyMem_Free(buf);

    return res;
}

static PyObject *
pint8vector_string(pint8vectorObject *self)
{
    /*  Create a simple string representation of the vector
        in the format [a, b, c, ...] without type casting */
    PyObject *res = NULL;
    PyObject **qs = NULL;
    Py_ssize_t bufsize = 0;
    char *buf = NULL, *ptr;
    Py_ssize_t i, len;

    /* Get the sequence length */
    if (PyList_Check(self->wrapped)) {
        len = PyList_GET_SIZE(self->wrapped);
    } else if (PyTuple_Check(self->wrapped)) {
        len = PyTuple_GET_SIZE(self->wrapped);
    } else {
        PyErr_SetString(PyExc_TypeError,
                        "int8vector must be initialized with a list or tuple");
        goto exit;
    }

    /* vectors must not be empty */
    if (len == 0) {
        PyErr_SetString(PyExc_ValueError,
                    "int8vector cannot be empty");
        goto exit;
    }

    if (!(qs = PyMem_New(PyObject *, len))) {
        PyErr_NoMemory();
        goto exit;
    }
    memset(qs, 0, len * sizeof(PyObject *));

    for (i = 0; i < len; i++) {
        PyObject *item;
        PyObject *str;
        long lval;

        /* Get the item from the sequence */
        if (PyList_Check(self->wrapped)) {
            item = PyList_GET_ITEM(self->wrapped, i);
        } else {
            item = PyTuple_GET_ITEM(self->wrapped, i);
        }

        /* Check if it's an integer (int or long) */
        if (!PyLong_Check(item)) {
            if (PyFloat_Check(item)) {
                PyErr_SetString(PyExc_TypeError,
                            "int8vector items must be integers (int), not float");
            } else {
                PyErr_SetString(PyExc_TypeError,
                            "int8vector items must be integers");
            }
            goto exit;
        }

        /* Convert to a long to check the range */
        lval = PyLong_AsLong(item);
        if (PyErr_Occurred()) goto exit;

        /* Check if value is within int8 range (-128 to 127) */
        if (lval < -128 || lval > 127) {
            PyErr_SetString(PyExc_ValueError,
                        "int8vector items must be in range -128 to 127");
            goto exit;
        }

        /* Convert the integer to string representation */
        str = PyObject_Str(item);
        if (!str) goto exit;

        qs[i] = PyUnicode_AsUTF8String(str);
        Py_DECREF(str);
        if (!qs[i]) goto exit;

        bufsize += Bytes_GET_SIZE(qs[i]) + 1;  /* element, comma */
    }

    /* Create the result string */
    if (!(ptr = buf = PyMem_Malloc(bufsize + 3))) {  /* Extra space for "[]" and null terminator */
        PyErr_NoMemory();
        goto exit;
    }

    /* Create the vector syntax */
    *ptr++ = '[';

    for (i = 0; i < len; i++) {
        Py_ssize_t sl;
        sl = Bytes_GET_SIZE(qs[i]);
        memcpy(ptr, Bytes_AS_STRING(qs[i]), sl);
        ptr += sl;

        *ptr++ = ',';
    }
    *(ptr - 1) = ']';

    res = Bytes_FromStringAndSize(buf, ptr - buf);

exit:
    if (qs) {
        for (i = 0; i < len; i++) {
            PyObject *q = qs[i];
            Py_XDECREF(q);
        }
        PyMem_Free(qs);
    }
    PyMem_Free(buf);

    return res;
}

static PyObject *
pint8vector_getquoted(pint8vectorObject *self, PyObject *args)
{
    return pint8vector_quote(self);
}

static PyObject *
pint8vector_getstring(pint8vectorObject *self, PyObject *args)
{
    return pint8vector_string(self);
}

/* Binary header size: 2 bytes length + 2 bytes reserved (zeros) */
#define BINARY_HEADER_SIZE 4

/* Get binary representation of vector with format:
* [16 bytes len]|[16 bytes reserved zeros]|[int8 values list]
*/
static PyObject *
pint8vector_getbinary(pint8vectorObject *self, PyObject *args)
{
    PyObject *res = NULL;
    char *buf = NULL;
    Py_ssize_t len, i;
    size_t buf_size;
    uint16_t net_len;
    PyObject *item = NULL;
    long lval;
    int8_t int8_val;
    char *data_section;

    /* Get the length of the vector */
    if (PyList_Check(self->wrapped)) {
        len = PyList_GET_SIZE(self->wrapped);
    } else if (PyTuple_Check(self->wrapped)) {
        len = PyTuple_GET_SIZE(self->wrapped);
    } else {
        PyErr_SetString(PyExc_TypeError,
                    "int8vector must be initialized with a list or tuple");
        return NULL;
    }

    /* vectors must not be empty */
    if (len == 0) {
        PyErr_SetString(PyExc_ValueError,
                    "int8vector cannot be empty");
        return NULL;
    }

    /* Calculate buffer size: header + int8 values */
    buf_size = BINARY_HEADER_SIZE + (len * sizeof(int8_t));

    /* Allocate memory for the buffer */
    if (!(buf = PyMem_Malloc(buf_size))) {
        PyErr_NoMemory();
        return NULL;
    }

    /* Initialize the buffer to zeros */
    memset(buf, 0, buf_size);

    /* Write the length (2 bytes) - use network byte order (big endian) */
    net_len = htons((uint16_t)len);
    memcpy(buf, &net_len, 2);

    /* The next 2 bytes are reserved and already set to zero */

    /* Set pointer to the int8 data section */
    data_section = buf + BINARY_HEADER_SIZE;

    /* Process each vector element */
    for (i = 0; i < len; i++) {
        /* Get the item */
        if (PyList_Check(self->wrapped)) {
            item = PyList_GET_ITEM(self->wrapped, i);
        } else {
            item = PyTuple_GET_ITEM(self->wrapped, i);
        }

        /* Check if it's an integer */
        if (!PyLong_Check(item)) {
            if (PyFloat_Check(item)) {
                PyErr_SetString(PyExc_TypeError,
                            "int8vector items must be integers (int), not float");
            } else {
                PyErr_SetString(PyExc_TypeError,
                            "int8vector items must be integers");
            }
            PyMem_Free(buf);
            return NULL;
        }

        /* Convert to long and check the range */
        lval = PyLong_AsLong(item);
        if (PyErr_Occurred()) {
            PyMem_Free(buf);
            return NULL;
        }

        /* Check if value is within int8 range (-128 to 127) */
        if (lval < -128 || lval > 127) {
            PyErr_SetString(PyExc_ValueError,
                        "int8vector items must be in range -128 to 127");
            PyMem_Free(buf);
            return NULL;
        }

        /* Convert long to int8_t */
        int8_val = (int8_t)lval;

        /* Copy the int8 value to the buffer at the correct position */
        memcpy(data_section + (i * sizeof(int8_t)), &int8_val, sizeof(int8_t));
    }

    /* Create a Python bytes object from the buffer */
    res = Bytes_FromStringAndSize(buf, buf_size);

    /* Free the buffer */
    PyMem_Free(buf);

    return res;
}

static PyObject *
pint8vector_repr(pint8vectorObject *self)
{
    return psyco_ensure_text(pint8vector_getquoted(self, NULL));
}

static PyObject *
pint8vector_str(pint8vectorObject *self)
{
    return psyco_ensure_text(pint8vector_getstring(self, NULL));
}

static PyObject *
pint8vector_conform(pint8vectorObject *self, PyObject *args)
{
    PyObject *res, *proto;

    if (!PyArg_ParseTuple(args, "O", &proto)) return NULL;

    if (proto == (PyObject*)&isqlquoteType)
        res = (PyObject*)self;
    else
        res = Py_None;

    Py_INCREF(res);
    return res;
}

/* Convert Int8Vector to Python list */
static PyObject *
pint8vector_tolist(pint8vectorObject *self, PyObject *args)
{
    if (PyList_Check(self->wrapped)) {
        Py_INCREF(self->wrapped);
        return self->wrapped;
    }
    else if (PyTuple_Check(self->wrapped)) {
        /* Convert tuple to list */
        return PySequence_List(self->wrapped);
    }

    /* This should never happen as we check in init */
    PyErr_SetString(PyExc_TypeError, "wrapped object is not a sequence");
    return NULL;
}

static Py_ssize_t
pint8vector_length(pint8vectorObject *self)
{
    if (PyList_Check(self->wrapped)) {
        return PyList_Size(self->wrapped);
    }
    else if (PyTuple_Check(self->wrapped)) {
        return PyTuple_Size(self->wrapped);
    }
    return 0;
}

/* Sequence methods */
static PySequenceMethods pint8vector_as_sequence = {
    (lenfunc)pint8vector_length,  /* sq_length */
    0,                            /* sq_concat */
    0,                            /* sq_repeat */
    0,                            /* sq_item */
    0,                            /* sq_slice */
    0,                            /* sq_ass_item */
    0,                            /* sq_ass_slice */
    0,                            /* sq_contains */
    0,                            /* sq_inplace_concat */
    0,                            /* sq_inplace_repeat */
};

/** the Int8Vector object **/

/* object member list */

static struct PyMemberDef pint8vectorObject_members[] = {
    {"adapted", T_OBJECT, offsetof(pint8vectorObject, wrapped), READONLY},
    {NULL}
};

/* object method table */

static PyMethodDef pint8vectorObject_methods[] = {
    {"getquoted", (PyCFunction)pint8vector_getquoted, METH_NOARGS,
     "getquoted() -> wrapped object value as SQL-quoted string"},
    {"getbinary", (PyCFunction)pint8vector_getbinary, METH_NOARGS,
    "getbinary() -> binary representation of the vector with format:\n"
    "[16 bytes len]|[16 bytes reserved zeros]|[int8 values list]"},
    {"__conform__", (PyCFunction)pint8vector_conform, METH_VARARGS, NULL},
    {"tolist", (PyCFunction)pint8vector_tolist, METH_NOARGS,
     "tolist() -> returns a copy of the vector as a Python list"},
    {NULL}  /* Sentinel */
};

/* initialization and finalization methods */

static int
pint8vector_setup(pint8vectorObject *self, PyObject *obj)
{
    Dprintf("pint8vector_setup: init pint8vector object at %p, refcnt = "
        FORMAT_CODE_PY_SSIZE_T,
        self, Py_REFCNT(self)
    );

    if (!PyList_Check(obj) && !PyTuple_Check(obj))
        return -1;

    Py_INCREF(obj);
    self->wrapped = obj;

    Dprintf("pint8vector_setup: good pint8vector object at %p, refcnt = "
        FORMAT_CODE_PY_SSIZE_T,
        self, Py_REFCNT(self)
    );
    return 0;
}

static int
pint8vector_traverse(pint8vectorObject *self, visitproc visit, void *arg)
{
    Py_VISIT(self->wrapped);
    return 0;
}

static int
pint8vector_clear(pint8vectorObject *self)
{
    Py_CLEAR(self->wrapped);
    return 0;
}

static void
pint8vector_dealloc(pint8vectorObject* self)
{
    PyObject_GC_UnTrack((PyObject *)self);
    pint8vector_clear(self);

    Dprintf("pint8vector_dealloc: deleted pint8vector object at %p, "
        "refcnt = " FORMAT_CODE_PY_SSIZE_T, self, Py_REFCNT(self));

    Py_TYPE(self)->tp_free((PyObject *)self);
}

static int
pint8vector_init(PyObject *obj, PyObject *args, PyObject *kwds)
{
    PyObject *l;

    if (!PyArg_ParseTuple(args, "O", &l))
        return -1;

    return pint8vector_setup((pint8vectorObject *)obj, l);
}

static PyObject *
pint8vector_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    return type->tp_alloc(type, 0);
}


/* object type */

#define pint8vectorType_doc \
"Int8Vector(list) -> new Int8 vector adapter object"

PyTypeObject pint8vectorType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "psycopg2._psycopg.Int8Vector",
    sizeof(pint8vectorObject), 0,
    (destructor)pint8vector_dealloc, /*tp_dealloc*/
    0,          /*tp_print*/
    0,          /*tp_getattr*/
    0,          /*tp_setattr*/
    0,          /*tp_compare*/
    (reprfunc)pint8vector_repr, /*tp_repr*/
    0,          /*tp_as_number*/
    &pint8vector_as_sequence, /*tp_as_sequence*/
    0,          /*tp_as_mapping*/
    0,          /*tp_hash */
    0,          /*tp_call*/
    (reprfunc)pint8vector_str, /*tp_str*/
    0,          /*tp_getattro*/
    0,          /*tp_setattro*/
    0,          /*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT|Py_TPFLAGS_BASETYPE|Py_TPFLAGS_HAVE_GC, /*tp_flags*/
    pint8vectorType_doc, /*tp_doc*/
    (traverseproc)pint8vector_traverse,          /*tp_traverse*/
    (inquiry)pint8vector_clear,          /*tp_clear*/
    0,          /*tp_richcompare*/
    0,          /*tp_weaklistoffset*/
    0,          /*tp_iter*/
    0,          /*tp_iternext*/
    pint8vectorObject_methods, /*tp_methods*/
    pint8vectorObject_members, /*tp_members*/
    0,          /*tp_getset*/
    0,          /*tp_base*/
    0,          /*tp_dict*/
    0,          /*tp_descr_get*/
    0,          /*tp_descr_set*/
    0,          /*tp_dictoffset*/
    pint8vector_init, /*tp_init*/
    0,          /*tp_alloc*/
    pint8vector_new, /*tp_new*/
};
