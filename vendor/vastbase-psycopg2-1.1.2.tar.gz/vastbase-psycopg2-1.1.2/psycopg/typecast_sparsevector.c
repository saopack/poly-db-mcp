/* typecast_sparsevector.c - sparsevector typecasting functions to python types
 *
 * Copyright (C) 2001-2019 Federico Di Gregorio <fog@debian.org>
 * Copyright (C) 2020-2021 The Psycopg Team
 *
 * This file is part of psycopg.
 *
 * psycopg2 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link this program with the OpenSSL library (or with
 * modified versions of OpenSSL that use the same license as OpenSSL),
 * and distribute linked combinations including the two.
 *
 * You must obey the GNU Lesser General Public License in all respects for
 * all of the code used other than OpenSSL.
 *
 * psycopg2 is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 */

#include "psycopg/psycopg.h"
#include "psycopg/adapter_psparsevector.h"

/** SPARSEVECTOR - cast sparsevec string into a Python SparseVector object **/
static PyObject *
typecast_SPARSEVECTOR_cast(const char *s, Py_ssize_t len, PyObject *curs)
{
    PyObject *pair_list = NULL;
    PyObject *rv = NULL;
    PyObject *float_obj = NULL;
    PyObject *pairs = NULL;
    PyObject *pairsAll = NULL;
    PyObject *max_dim_obj = NULL;
    const char *p = s;
    const char *end = s + len;
    char *endptr;
    double value;
    long max_index = -1;
    PyObject *idx_obj = NULL;

    if (s == NULL)
    {
        Py_RETURN_NONE;
    }

    /* 检查格式是否正确：必须以'['开始 */
    if (len < 2 || *p != '[')
    {
        PyErr_SetString(PyExc_ValueError, "vector must start with '['");
        return NULL;
    }

    /* 检查格式是否正确：必须以']'结束 */
    if (*(end - 1) != ']')
    {
        PyErr_SetString(PyExc_ValueError, "vector must end with ']'");
        return NULL;
    }

    /* 创建键值对列表 */
    pair_list = PyList_New(0);
    if (pair_list == NULL)
    {
        return NULL;
    }

    /* 跳过开头的'[' */
    p++;

    /* 空向量检查 */
    if (p >= end - 1)
    {
        PyErr_SetString(PyExc_ValueError, "sparse vector cannot be empty");
        Py_DECREF(pair_list);
        return NULL;
    }

    do
    {
        long index;

        if (!p)
        {
            PyErr_SetString(PyExc_ValueError, "invalid index in vector");
            Py_DECREF(pair_list);
            return NULL;
        }

        /* 解析索引部分 */
        index = strtol(p, &endptr, 10);
        if (p == endptr)
        {
            PyErr_SetString(PyExc_ValueError, "invalid index in vector");
            Py_DECREF(pair_list);
            return NULL;
        }

        p = endptr;

        /* 检查是否有 ':' 分隔符 */
        if (p >= end || *p != ':')
        {
            PyErr_SetString(PyExc_ValueError, "index and value must be separated by ':'");
            Py_DECREF(pair_list);
            return NULL;
        }
        p++; /* 跳过 ':' */

        /* 转换值 */
        value = strtod(p, &endptr);

        /* 检查转换是否成功 */
        if (p == endptr)
        {
            PyErr_SetString(PyExc_ValueError, "invalid number in vector");
            Py_DECREF(pair_list);
            return NULL;
        }

        /* 更新指针 */
        p = endptr;

        /* 只存储非零值（稀疏向量特性） */
        if (value != 0.0)
        {
            PyObject *pair_tuple = PyTuple_New(2);
            if (pair_tuple == NULL)
            {
                Py_DECREF(pair_list);
                return NULL;
            }

            /* 创建索引对象 */
            idx_obj = PyLong_FromLong(index);
            if (idx_obj == NULL)
            {
                Py_DECREF(pair_tuple);
                Py_DECREF(pair_list);
                return NULL;
            }
            PyTuple_SET_ITEM(pair_tuple, 0, idx_obj);

            /* 创建值对象 */
            float_obj = PyFloat_FromDouble(value);
            if (float_obj == NULL)
            {
                Py_DECREF(pair_tuple);
                Py_DECREF(pair_list);
                return NULL;
            }
            PyTuple_SET_ITEM(pair_tuple, 1, float_obj);

            /* 添加到键值对列表 */
            if (PyList_Append(pair_list, pair_tuple) < 0)
            {
                Py_DECREF(pair_tuple);
                Py_DECREF(pair_list);
                return NULL;
            }
            Py_DECREF(pair_tuple);
        }

        /* 更新最大索引 */
        if (index > max_index)
        {
            max_index = index;
        }

        /* 检查是否到达结尾或需要逗号 */
        if (p < end - 1)
        {
            if (*p != ',')
            {
                PyErr_SetString(PyExc_ValueError, "elements must be separated by commas");
                Py_DECREF(pair_list);
                return NULL;
            }
            p++; /* 跳过逗号 */
        }

    } while (p < end - 1);

    /* 创建 max_dim 对象（维度是 max_index + 1）*/
    if (max_index < 0)
    {
        PyErr_SetString(PyExc_ValueError, "sparse vector has no valid elements");
        Py_DECREF(pair_list);
        return NULL;
    }

    max_dim_obj = PyLong_FromLong(max_index + 1);
    if (max_dim_obj == NULL)
    {
        Py_DECREF(pair_list);
        return NULL;
    }

    /* 创建元组 (pairs, max_dim) */
    pairs = PyTuple_New(2);
    if (pairs == NULL)
    {
        Py_DECREF(pair_list);
        Py_DECREF(max_dim_obj);
        return NULL;
    }

    PyTuple_SET_ITEM(pairs, 0, pair_list);   /* 键值对列表 */
    PyTuple_SET_ITEM(pairs, 1, max_dim_obj); /* 最大维度 */

    pairsAll = PyTuple_New(1);
    if (pairsAll == NULL)
    {
        Py_DECREF(pairs);
        return NULL;
    }

    PyTuple_SET_ITEM(pairsAll, 0, pairs); /* 键值对列表 */

    rv = PyObject_CallFunction((PyObject *)&psparsevectorType, "O", pairsAll);

    Py_DECREF(pairsAll);

    return rv;
}
