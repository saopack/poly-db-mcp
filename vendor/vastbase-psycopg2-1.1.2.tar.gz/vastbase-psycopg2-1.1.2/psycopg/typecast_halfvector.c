/* typecast_halfvector.c - halfvector typecasting functions to python types
 *
 * Copyright (C) 2001-2019 Federico Di Gregorio <fog@debian.org>
 * Copyright (C) 2020-2021 The Psycopg Team
 *
 * This file is part of psycopg.
 *
 * psycopg2 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link this program with the OpenSSL library (or with
 * modified versions of OpenSSL that use the same license as OpenSSL),
 * and distribute linked combinations including the two.
 *
 * You must obey the GNU Lesser General Public License in all respects for
 * all of the code used other than OpenSSL.
 *
 * psycopg2 is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 */

#include "psycopg/psycopg.h"
#include "psycopg/adapter_phalfvector.h"


/** HALFVECTOR - cast halfvector string into a Python HalfVector object **/

static PyObject *
typecast_HALFVECTOR_cast(const char *s, Py_ssize_t len, PyObject *curs)
{
    PyObject *list = NULL;
    PyObject *rv = NULL;
    PyObject *float_obj = NULL;
    const char *p = s;
    const char *end = s + len;
    char *endptr;
    double value;

    if (s == NULL) { Py_RETURN_NONE; }

    /* 检查格式是否正确：必须以'['开始 */
    if (len < 2 || *p != '[') {
        PyErr_SetString(PyExc_ValueError, "vector must start with '['");
        return NULL;
    }

    /* 检查格式是否正确：必须以']'结束 */
    if (*(end-1) != ']') {
        PyErr_SetString(PyExc_ValueError, "vector must end with '] '");
        return NULL;
    }

    /* 创建一个空列表 */
    list = PyList_New(0);
    if (list == NULL) { return NULL; }

    /* 跳过开头的'[' */
    p++;

    /* 空向量检查 */
    if (p < end - 1) {
        do {
            if(!p) {
                PyErr_SetString(PyExc_ValueError, "invalid number in vector");
                Py_DECREF(list);
                return NULL;
            }
            /* 转换数字 */
            value = strtod(p, &endptr);

            /* 检查转换是否成功 */
            if (p == endptr) {
                PyErr_SetString(PyExc_ValueError, "invalid number in vector");
                Py_DECREF(list);
                return NULL;
            }

            /* 将值添加到列表 */
            float_obj = PyFloat_FromDouble(value);
            if (float_obj == NULL || PyList_Append(list, float_obj) < 0) {
                Py_XDECREF(float_obj);
                Py_DECREF(list);
                return NULL;
            }
            Py_DECREF(float_obj);

            /* 更新指针 */
            p = endptr;

            /* 检查是否到达结尾或需要逗号 */
            if (p < end - 1) {
                if (*p != ',') {
                    PyErr_SetString(PyExc_ValueError, "elements must be separated by commas");
                    Py_DECREF(list);
                    return NULL;
                }
                p++; /* 跳过逗号 */
            }

        } while (p < end - 1);
    }

    /* 将列表包装在 HalfVector 对象中 */
    rv = PyObject_CallFunction((PyObject *)&phalfvectorType, "O", list);
    Py_DECREF(list);

    return rv;
}
